<?php
session_start();
include 'connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, password, user_type, name FROM users WHERE email = ?"); // Fetch name as well
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 1) {
        $stmt->bind_result($id, $stored_password, $user_type, $name); // Bind name
        $stmt->fetch();

        // Use password_verify for password verification
        if (password_verify($password, $stored_password)) {
            $_SESSION['user_id'] = $id;
            $_SESSION['user_type'] = $user_type;
            $_SESSION['email'] = $email; // Store email in session
            $_SESSION['name'] = $name; // Store name in session

            // Redirect based on user type
            switch ($user_type) {
                case 'student':
                    header("Location: Student/index.php");
                    break;
                case 'alumni':
                    header("Location: Alumni/index.php");
                    break;
                case 'admin':
                    header("Location: Admin/index.php");
                    break;
                default:
                    $error = "Invalid user type";
            }
            exit();
        } else {
            $error = "Invalid email or password (password mismatch)";
        }
    } else {
        $error = "Invalid email or password (email not found)";
    }

    $stmt->close();
    $conn->close();
}

// // Display error message
// if(isset($error)) {
//     echo "<p style='color: red;'>$error</p>";
// }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CHARUSAT - Login</title>
    <link rel="stylesheet" href="login.css">
    <style>
        .required::after {
            content: " *";
            color: red;
        }
    </style>
</head>
<body>
    
    <div class="container">
        <div class="left-panel">
            <div class="logo-circle">
                <img src="images/University_Hero.png" alt="CHARUSAT Logo">
            </div>
        </div>
        <div class="right-panel">
            <div class="login-form">
                <div class="login-logo">
                    <img src="images/logo.png" alt="CHARUSAT Logo">
                </div>
                <h2>Login</h2>
    <?php if(isset($error)) { echo "<p style='color: red;'>$error</p>"; } ?>
    <form action="login.php" method="POST">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br><br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br><br>
        <button type="submit">Login</button>
    </form>
            
                <div class="links-container">
                    <div class="signup">
                        <a href="register.php">Sign Up</a>
                    </div>
                    <div class="forgot-password">
                        <a href="forgot.php">Forgot Password?</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>