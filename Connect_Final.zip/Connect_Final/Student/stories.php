<?php
include '../connect.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: ../home.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch all approved stories from all alumni
$all_stories_query = "SELECT s.*, u.name as alumni_name 
                     FROM alumni_stories s 
                     JOIN users u ON s.user_id = u.id 
                     WHERE s.status = 'approved' 
                     ORDER BY s.created_at DESC";
$all_stories = mysqli_query($conn, $all_stories_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alumni Stories - Charusat Alumni System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="topnav" id="myTopnav">
    <div class="logo">
        <img src="image/logo.png" alt="CHARUSAT Logo" style="background-color: white; height: 52px; vertical-align: middle;">
        <span style="vertical-align: middle; ">CE Connect</span>
    </div>
        <div class="topnav-right">
            <a href="index.php">Home</a>
            <a href="alumni.php">Alumni</a>
            <a href="events.php">Events</a>
            <a href="jobs.php">Job Post</a>
            <a href="stories.php" class="active">Stories</a>
            <a href="syllabus.php" >Syllabus</a>
            <a href="achievement.php">Achievements</a>
            <a href="gallery.php">Gallery</a>
            <a href="help.php">Help</a>
            <a href="profile.php" >Profile</a>
            <a href="#" onclick="confirmLogout()">Logout</a>
            <div class="search-container">
                <input type="text" placeholder="Search...">
                <button type="submit">🔍</button>
            </div>
            <!-- <div class="profile-icon">
                <img src="Profile.jpg" alt="Profile" class="avatar" height="52px">
            </div> -->
        </div>
    </div>

    <div class="main-content">
        <div class="header">
            <h2>Alumni Stories</h2>
        </div>

        <div class="jobs-list">
            <table class="jobs-table">
                <thead>
                    <tr>
                        <th>Alumni Name</th>
                        <th>Title</th>
                        <th>Category</th>
                        <th>Story</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($all_stories)) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['alumni_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['title']); ?></td>
                            <td><?php echo htmlspecialchars($row['category']); ?></td>
                            <td><?php echo htmlspecialchars(substr($row['description'], 0, 50)); ?>...</td>
                            <td>
                                <button onclick="openStoryModal('<?php echo htmlspecialchars($row['title']); ?>', '<?php echo htmlspecialchars($row['description']); ?>', '<?php echo htmlspecialchars($row['alumni_name']); ?>')" class="view-btn">View</button>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Add Modal HTML -->
    <div id="storyModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2 id="modalTitle"></h2>
            <p><strong>By: </strong><span id="modalAuthor"></span></p>
            <div id="modalDescription"></div>
        </div>
    </div>

    <!-- Add CSS -->
    <style>
    .modal {
        display: none;
        position: fixed;
        z-index: 1;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgba(0,0,0,0.4);
    }

    .modal-content {
        background-color: #fefefe;
        margin: 15% auto;
        padding: 20px;
        border: 1px solid #888;
        width: 80%;
        max-width: 600px;
        border-radius: 5px;
    }

    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
    }

    .close:hover,
    .close:focus {
        color: black;
        text-decoration: none;
        cursor: pointer;
    }

    .view-btn {
        background-color: #4CAF50;
        color: white;
        padding: 6px 12px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    .view-btn:hover {
        background-color: #45a049;
    }

    #modalDescription {
        margin-top: 20px;
        line-height: 1.6;
        white-space: pre-wrap;
    }
    </style>

    <!-- Add JavaScript -->
    <script>
    var modal = document.getElementById("storyModal");
    var span = document.getElementsByClassName("close")[0];

    function openStoryModal(title, description, author) {
        document.getElementById("modalTitle").textContent = title;
        document.getElementById("modalAuthor").textContent = author;
        document.getElementById("modalDescription").textContent = description;
        modal.style.display = "block";
    }

    // Close modal when clicking the X
    span.onclick = function() {
        modal.style.display = "none";
    }

    // Close modal when clicking outside
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

    // Close modal with Escape key
    document.addEventListener('keydown', function(event) {
        if (event.key === "Escape") {
            modal.style.display = "none";
        }
    });
    </script>

    <script>
    function confirmLogout() {
        if (confirm("Are you sure you want to logout?")) {
            fetch('logout.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=logout'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert("You have been successfully logged out.");
                    window.location.href = '../home.php'; 
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert("An error occurred during logout. Please try again.");
            });
        }
    }
    </script>
</body>
</html>

<?php include 'footer.php'; ?>