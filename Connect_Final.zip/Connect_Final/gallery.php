<?php 
session_start();
include 'connect.php'; // Include database connection

if (!isset($_SESSION['email'])) {
    // Redirect to a different page if not set
    header('Location: ../home.php');
    exit; // Ensure no further code is executed
}

// Function to handle image upload
function handleImageUpload($conn) {
    $category = filter_input(INPUT_POST, 'category', FILTER_SANITIZE_STRING);
    $baseUploadDir = __DIR__ . '/../uploads/'; // Adjusted to point to the main uploads directory
    $uploadDir = $baseUploadDir . $category . '/';
    
    // Debug output
    error_log("Base Upload Directory: " . $baseUploadDir);
    error_log("Category Upload Directory: " . $uploadDir);
    error_log("Category: " . $category);
    
    // Create base uploads directory if it doesn't exist
    if (!file_exists($baseUploadDir)) {
        mkdir($baseUploadDir, 0777, true);
        error_log("Created base uploads directory: " . $baseUploadDir);
    }
    
    // Create category directory if it doesn't exist
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
        error_log("Created category directory: " . $uploadDir);
    }

    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
    $maxFileSize = 5 * 1024 * 1024; // 5MB

    if ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        error_log("Upload error code: " . $_FILES['image']['error']);
        return ['success' => false, 'message' => 'Upload failed. Please try again.'];
    }

    if (!in_array($_FILES['image']['type'], $allowedTypes)) {
        error_log("Invalid file type: " . $_FILES['image']['type']);
        return ['success' => false, 'message' => 'Invalid file type. Only JPG, PNG and GIF are allowed.'];
    }

    if ($_FILES['image']['size'] > $maxFileSize) {
        error_log("File too large: " . $_FILES['image']['size']);
        return ['success' => false, 'message' => 'File is too large. Maximum size is 5MB.'];
    }

    $fileName = uniqid() . '_' . basename($_FILES['image']['name']);
    $relativePath = 'uploads/' . $category . '/' . $fileName; // Use forward slashes for web paths
    $absolutePath = $uploadDir . $fileName; // Path for actual file storage

    error_log("Relative path for DB: " . $relativePath);
    error_log("Absolute path for storage: " . $absolutePath);

    // First get the user's ID from the users table using their email
    $email = $_SESSION['email'];
    $userStmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $userStmt->bind_param("s", $email);
    $userStmt->execute();
    $userResult = $userStmt->get_result();
    
    if (!$userResult->num_rows) {
        return ['success' => false, 'message' => 'User not found.'];
    }
    
    $userData = $userResult->fetch_assoc();
    $userId = $userData['id'];

    if (move_uploaded_file($_FILES['image']['tmp_name'], $absolutePath)) {
        error_log("File uploaded successfully to: " . $absolutePath);
        $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);
        
        // Store relative path in database
        $stmt = $conn->prepare("INSERT INTO gallery_images (image_path, category, description, upload_date, uploaded_by) VALUES (?, ?, ?, NOW(), ?)");
        $stmt->bind_param("ssss", $relativePath, $category, $description, $userId);
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => 'Image uploaded successfully!'];
        } else {
            unlink($absolutePath);
            error_log("Database error: " . $stmt->error);
            return ['success' => false, 'message' => 'Database error: ' . $stmt->error];
        }
    } else {
        error_log("Failed to move uploaded file to: " . $absolutePath);
        error_log("Upload error: " . error_get_last()['message']);
    }
    
    return ['success' => false, 'message' => 'Failed to move uploaded file.'];
}

// Function to delete image
function deleteImage($conn, $imageId) {
    $stmt = $conn->prepare("SELECT image_path FROM gallery_images WHERE id = ?");
    $stmt->bind_param("i", $imageId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        $imagePath = $row['image_path'];
        
        $deleteStmt = $conn->prepare("DELETE FROM gallery_images WHERE id = ?");
        $deleteStmt->bind_param("i", $imageId);
        
        if ($deleteStmt->execute()) {
            if (file_exists($imagePath)) {
                unlink($imagePath);
            }
            return ['success' => true, 'message' => 'Image deleted successfully!'];
        }
    }
    
    return ['success' => false, 'message' => 'Failed to delete image.'];
}

// Handle POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['image'])) {
        $result = handleImageUpload($conn);
        $_SESSION['message'] = $result['message'];
        $_SESSION['message_type'] = $result['success'] ? 'success' : 'error';
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
    
    if (isset($_POST['delete_image'])) {
        $imageId = filter_input(INPUT_POST, 'delete_image', FILTER_VALIDATE_INT);
        $result = deleteImage($conn, $imageId);
        echo json_encode($result);
        exit;
    }
}

// Fetch images for display
$stmt = $conn->prepare("
    SELECT 
        gi.id,
        gi.image_path,
        gi.description,
        gi.upload_date,
        u.email as uploaded_by_email
    FROM gallery_images gi
    JOIN users u ON gi.uploaded_by = u.email
    ORDER BY gi.upload_date DESC
");
$stmt->execute();
$result = $stmt->get_result();

// Define the base path
$basePath = 'C:/xampp/htdocs/Connect_Final/'; // Adjust this path as necessary
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gallery - Charusat Alumni System</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style2.css">
</head>
<body>
<div class="topnav" id="myTopnav">
    <div class="logo">
        <img src="image/logo.png" alt="CHARUSAT Logo" style="background-color: white; height: 52px; vertical-align: middle;">
        <span>CE Connect</span>
    </div>
    <div class="topnav-right">
        <a href="index.php">Home</a>
        <a href="alumni.php">Alumni</a>
        <a href="events.php">Events</a>
        <a href="jobs.php">Job Post</a>
        <a href="stories.php">Stories</a>
        <a href="gallery.php" class="active">Gallery</a>
        <a href="help.php">Help</a>
        <a href="profile.php">Profile</a>
        <a href="#" onclick="confirmLogout()">Logout</a>
        <div class="search-container">
            <input type="text" placeholder="Search...">
            <button type="submit">🔍</button>
        </div>
    </div>
</div>
<div class="main-content">
    <div class="header" style="margin-top: -10px;">
        <h2>Gallery</h2>
    </div>

    <?php if (isset($_SESSION['message'])): ?>
        <div class="message <?php echo $_SESSION['message_type']; ?>">
            <?php 
                echo $_SESSION['message'];
                unset($_SESSION['message']);
                unset($_SESSION['message_type']);
            ?>
        </div>
    <?php endif; ?>

    <div class="upload-section">
        <button class="category-toggle" onclick="toggleUpload()">
            <h4>Upload Image</h4> <span class="arrow">▼</span>
        </button>
        <div id="upload-form-section" class="category-content">
            <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST" enctype="multipart/form-data" class="add-event">
                <table class="form-table">
                    <tr>
                        <td>
                            <div class="form-group">
                                <label for="image">Choose Image:</label>
                                <input type="file" name="image" accept="image/*" required>
                            </div>
                            <br>
                            <div class="form-group">
                                <label for="category">Category:</label>
                                <select name="category" required>
                                    <option value="event">Event</option>
                                    <option value="sports">Sports</option>
                                    <option value="campus">Campus</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="description">Description:</label>
                                <textarea name="description" rows="3" placeholder="Optional description"></textarea>
                            </div>
                            
                            <button type="submit" class="view-btn">Upload</button>
                        </td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
    <img src="../Connect_final/uploads/campus/67a73e85b35db_showcase3.jpeg" alt="NA">

    <div class="gallery-sections">
        <h3>All Images</h3>
        <div class="gallery-content">
            <?php
            // Reset the result pointer
            $stmt->data_seek(0);
            while ($row = $result->fetch_assoc()):
                // Combine base path with image path from the database
                $fullImagePath = $basePath . htmlspecialchars($row['image_path']);
                // Debugging output
                error_log("Processing image path: " . $fullImagePath);
            ?>
                <div class="gallery-item">
                    <h5>img</h5>
                    <img src="C:/xampp/htdocs/Connect_Final/uploads/campus/67a73e85b35db_showcase3.jpeg" alt="C:/xampp/htdocs/Connect_Final/uploads/campus/67a73e85b35db_showcase3.jpeg">
                    <img src="<?php echo $fullImagePath; ?>" 
                         alt="<?php echo htmlspecialchars($row['description']); ?>">
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</div>

<style>
.category-section {
    margin-bottom: 20px;
}

.category-toggle {
    width: 100%;
    padding: 10px;
    background-color: #f0f0f0;
    border: none;
    text-align: left;
    font-size: 18px;
    cursor: pointer;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.category-toggle:hover {
    background-color: #e0e0e0;
}

.category-content {
    display: none;
    padding: 20px;
    background-color: #fff;
    border: 1px solid #ddd;
}

.category-content.active {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 20px;
}

.arrow {
    transition: transform 0.3s ease;
}

.category-toggle.active .arrow {
    transform: rotate(180deg);
}

.upload-section {
    margin-bottom: 30px;
}

.upload-section .category-toggle {
    margin-bottom: 0;
}

.upload-section .category-content {
    padding: 20px;
}

.upload-section .category-content.active {
    display: block;
}
</style>

<script>
function toggleCategory(category) {
    const content = document.getElementById(category + '-section');
    const toggle = content.previousElementSibling;
    const arrow = toggle.querySelector('.arrow');
    
    // Close all other sections
    document.querySelectorAll('.category-content').forEach(section => {
        if (section !== content) {
            section.classList.remove('active');
            section.previousElementSibling.classList.remove('active');
        }
    });
    
    // Toggle the clicked section
    content.classList.toggle('active');
    toggle.classList.toggle('active');
}

// Lightbox functionality
function openLightbox(img) {
    const lightbox = document.getElementById('lightbox');
    const lightboxImg = document.getElementById('lightbox-img');
    const caption = document.getElementById('lightbox-caption');
    
    lightboxImg.src = img.src;
    caption.textContent = img.alt;
    lightbox.style.display = 'block';
}

function closeLightbox() {
    document.getElementById('lightbox').style.display = 'none';
}

// Delete functionality
function deleteImage(imageId) {
    if (confirm('Are you sure you want to delete this image?')) {
        fetch('<?php echo $_SERVER['PHP_SELF']; ?>', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'delete_image=' + imageId
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert(data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while deleting the image.');
        });
    }
}

// Logout functionality
function confirmLogout() {
    if (confirm("Are you sure you want to logout?")) {
        fetch('logout.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=logout'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                window.location.href = '../home.php';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert("An error occurred during logout. Please try again.");
        });
    }
}

function toggleUpload() {
    const content = document.getElementById('upload-form-section');
    const toggle = content.previousElementSibling;
    const arrow = toggle.querySelector('.arrow');
    
    content.classList.toggle('active');
    toggle.classList.toggle('active');
}
</script>

</body>
</html>

<?php 
$conn->close();
include 'footer.php'; 
?>