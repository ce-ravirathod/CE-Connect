<?php
session_start();
include 'connect.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate input data
    $id = $conn->real_escape_string($_POST['id']);
    $date = $conn->real_escape_string($_POST['date']);
    $company_name = $conn->real_escape_string($_POST['company_name']);
    $job_type = $conn->real_escape_string($_POST['type']);
    $requirements = $conn->real_escape_string($_POST['requirements']);

    // Prepare SQL statement
    $sql = "UPDATE job_posts SET date = ?, company_name = ?, job_type = ?, requirements = ? WHERE id = ?";
    
    // Create a prepared statement
    $stmt = $conn->prepare($sql);
    
    // Bind parameters to the prepared statement
    $stmt->bind_param("ssssi", $date, $company_name, $job_type, $requirements, $id);
    
    // Execute the statement
    if ($stmt->execute()) {
        header("Location: jobs.php?message=Job post updated successfully!");
        exit();
    } else {
        $message = "Error: " . $stmt->error;
    }
    
    // Close the statement
    $stmt->close();
}

// Fetch job post data for the given ID
if (isset($_GET['id'])) {
    $id = $conn->real_escape_string($_GET['id']);
    $sql = "SELECT * FROM job_posts WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    
    // Bind the result variables
    $stmt->bind_result($fetched_id, $fetched_date, $fetched_company_name, $fetched_job_type, $fetched_requirements);
    
    // Fetch the result
    if ($stmt->fetch()) {
        $job_post = array( // Changed from [] to array()
            'id' => $fetched_id,
            'date' => $fetched_date,
            'company_name' => $fetched_company_name,
            'job_type' => $fetched_job_type,
            'requirements' => $fetched_requirements
        );
    } else {
        die("Job post not found.");
    }
    $stmt->close();
} else {
    die("No ID provided.");
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Job Post</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="topnav" id="myTopnav">
    <div class="logo">
        <img src="image/logo.png" alt="CHARUSAT Logo" style="background-color: white; height: 52px; vertical-align: middle;">
        <span style="vertical-align: middle; ">CE Connect</span>
    </div>
        <div class="topnav-right">
            <a href="index.php">Home</a>
            <a href="alumni.php">Alumni</a>
            <a href="events.php">Events</a>
            <a href="jobs.php" class="active">Job Post</a>
            <a href="gallery.php">Gallery</a>
            <a href="help.php">Help</a>
            <a href="profile.php" >Profile</a>
            <a href="#" onclick="confirmLogout()">Logout</a>
            <div class="search-container">
                <input type="text" placeholder="Search...">
                <button type="submit">🔍</button>
            </div>
            <!-- <div class="profile-icon">
                <img src="Profile.jpg" alt="Profile" class="avatar" height="52px">
            </div> -->
        </div>
    </div>
   
    <div class="main-content">
    <div class="header">
    <h2>Update Job Post</h2> 
        </div>
        <form class="form-table" action="update_job_post.php" method="POST">
    <input type="hidden" name="id" value="<?php echo htmlspecialchars($job_post['id']); ?>">
    <table class="form-table" >
        <tr>
            <td>
                <label for="date">Job post date:</label>
                <input type="date" id="date" name="date" value="<?php echo htmlspecialchars($job_post['date']); ?>" required>
            </td>
            <td>
                <label for="company_name">Company Name:</label>
                <input type="text" id="company_name" name="company_name" value="<?php echo htmlspecialchars($job_post['company_name']); ?>" required>
            </td>
        </tr>
        <tr>
            <td>
                <label for="requirements">Requirements:</label>
                <textarea id="requirements" name="requirements" rows="4" required><?php echo htmlspecialchars($job_post['requirements']); ?></textarea>
            </td>
            <td>
                <label for="type">Job Type:</label>
                <select id="type" name="type" required>
                    <option value="Full Time" <?php if ($job_post['job_type'] == 'Full Time') echo 'selected'; ?>>Full Time</option>
                    <option value="Part Time" <?php if ($job_post['job_type'] == 'Part Time') echo 'selected'; ?>>Part Time</option>
                    <option value="Internship" <?php if ($job_post['job_type'] == 'Internship') echo 'selected'; ?>>Internship</option>
                </select>
                <br><br>
                <div style="text-align: right;">
                    <button class='btn1'>Cancel</button>
                    <button class='btn2'>Update Job Post</button>
</div>
            </td>
           
            
</tr>
    </table>
</form>


    <script>
    function confirmLogout() {
        if (confirm("Are you sure you want to logout?")) {
            fetch('logout.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=logout'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert("You have been successfully logged out.");
                    window.location.href = '../home.php'; 
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert("An error occurred during logout. Please try again.");
            });
        }
    }
    </script>
</div>
</body>
</html>