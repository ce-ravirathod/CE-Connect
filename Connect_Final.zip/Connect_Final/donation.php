<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CE Connect - Donation</title>
    <link href="styles/common.css" rel="stylesheet">
    <link href="styles/donation.css" rel="stylesheet">
    <link href="styles/header_footer.css" rel="stylesheet">
    <script src="js/main.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <nav class="header-topnav">
        <div class="header-logo">
            <img src="https://d2lk14jtvqry1q.cloudfront.net/media/large_Charotar_University_of_Science_and_Technology_CHARUSAT_Anand_fdce544903_1202e15c5f.png" alt="CHARUSAT Logo">
            <span>CE Connect</span>
        </div>
        <div class="header-menu-icon" onclick="toggleMenu()">&#9776;</div>
        <div class="header-topnav-right">
            <a href="home.php">Home</a>
            <a href="aboutus.php">About Us</a>
            <a href="donation.php" class="active">Donation</a>
            <a  href="login.php">Login</a>
        </div>
    </nav>

    <main class="donation-container">
        <section class="construction-message">
            <i class="fas fa-tools"></i>
            <h2>Under Construction</h2>
            <p>We're working hard to bring you an amazing donation experience. Please check back soon!</p>
            <div class="progress-bar">
                <div class="progress"></div>
            </div>
            <button class="notify-btn">Notify Me When Ready</button>
        </section>
    </main>
    
    <?php include('footer.php'); ?>
</body>
</html>