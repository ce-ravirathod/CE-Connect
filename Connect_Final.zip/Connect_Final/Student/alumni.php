<?php
session_start();
if (!isset($_SESSION['email'])) {
    header('Location: ../home.php');
    exit;
}

include 'connect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alumni Records - Charusat Alumni System</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .batch-folders {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 20px;
            padding: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .folder {
            background: #f0f8ff;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 1px solid #ddd;
            position: relative;
            min-height: 150px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .folder.active:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            background: #e6f3ff;
        }

        .folder-icon {
            font-size: 48px;
            margin-bottom: 15px;
            color: #007bff;
        }

        .folder-label {
            font-weight: bold;
            color: #333;
            font-size: 16px;
        }

        .alumni-count {
            position: absolute;
            top: 10px;
            right: 10px;
            background: #007bff;
            color: white;
            border-radius: 50%;
            width: 28px;
            height: 28px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            font-weight: bold;
        }

        .back-btn {
            margin: 20px 0;
            padding: 10px 20px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .back-btn:hover {
            background: #0056b3;
        }

        #batch-title {
            text-align: center;
            color: #333;
            margin: 20px 0;
            font-size: 24px;
            font-weight: bold;
        }

        .alumni-list table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: white;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }

        .alumni-list th, .alumni-list td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .alumni-list th {
            background: #f8f9fa;
            font-weight: bold;
        }

        .alumni-list tr:hover {
            background: #f5f5f5;
        }

        .loading {
            text-align: center;
            padding: 20px;
            display: none;
        }

        .folder.empty {
            opacity: 0.7;
            background: #f5f5f5;
        }

        .folder.empty:hover {
            transform: none;
            background: #f0f0f0;
            cursor: default;
        }

        .folder.empty .alumni-count {
            background: #999;
        }

        .folder.empty .folder-icon {
            color: #999;
        }

        .year-filter {
            margin: 20px auto;
            text-align: center;
            max-width: 600px;
        }

        .year-filter select {
            padding: 8px 15px;
            font-size: 16px;
            border-radius: 5px;
            border: 1px solid #ddd;
            margin: 0 10px;
        }

        /* Header and Button Styles */
        .header-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 20px 0;
            padding: 0 20px;
        }

        .back-btn {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .back-btn:hover {
            background-color: #218838;
            transform: translateY(-2px);
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        /* Table Styles */
        .alumni-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            margin: 20px 0;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }

        .alumni-table thead th {
            background-color: #f8f9fa;
            color: #333;
            font-weight: 600;
            padding: 15px;
            text-align: left;
            border-bottom: 2px solid #dee2e6;
            text-transform: uppercase;
            font-size: 14px;
        }

        .alumni-table tbody td {
            padding: 12px 15px;
            border-bottom: 1px solid #eee;
            color: #333;
            font-size: 14px;
        }

        .alumni-table tbody tr:last-child td {
            border-bottom: none;
        }

        .alumni-table tbody tr:hover {
            background-color: #f5f8ff;
            transition: background-color 0.3s ease;
        }

        /* Responsive table */
        @media screen and (max-width: 768px) {
            .alumni-table {
                display: block;
                overflow-x: auto;
                white-space: nowrap;
            }
            
            .header-actions {
                flex-direction: column;
                gap: 10px;
                align-items: flex-start;
            }
            
            .back-btn {
                align-self: flex-end;
            }
        }

        /* Null value styling */
        .alumni-table tbody td:empty::after,
        .alumni-table tbody td:contains("null")::after {
            content: "—";
            color: #999;
        }
    </style>
</head>
<body>
    <div class="topnav" id="myTopnav">
    <div class="logo">
        <img src="image/logo.png" alt="CHARUSAT Logo" style="background-color: white; height: 52px; vertical-align: middle;">
        <span style="vertical-align: middle; ">CE Connect</span>
    </div>
        <div class="topnav-right">
            <a href="index.php">Home</a>
            <a href="alumni.php" class="active">Alumni</a>
            <a href="events.php">Events</a>
            <a href="jobs.php">Job Post</a>
            <a href="stories.php" >Stories</a>
            <a href="syllabus.php" >Syllabus</a>
            <a href="achievement.php">Achievements</a>
            <a href="gallery.php">Gallery</a>
            <a href="help.php">Help</a>
            <a href="profile.php" >Profile</a>
            <a href="#" onclick="confirmLogout()">Logout</a>
            <div class="search-container">
                <input type="text" placeholder="Search...">
                <button type="submit">🔍</button>
            </div>
        </div>
    </div>

    <div class="main-content">
        <div class="header">
            <h2>Alumni Batch Directory</h2>
        </div>

        <div class="year-filter">
            <select id="yearRange" onchange="filterYears()">
                <option value="all">All Years</option>
                <option value="recent">Recent (2020-2024)</option>
                <option value="older">Older (2004-2019)</option>
            </select>
        </div>

        <div class="batch-folders">
            <?php
            try {
                // Create an array of all years from 2024 to 2004
                $years = range(2024, 2004);
                
                // Get count of alumni per batch
                $sql = "SELECT passing_year, COUNT(*) as count 
                        FROM users 
                        WHERE user_type = 'alumni' 
                        GROUP BY passing_year";
                $result = $conn->query($sql);
                
                // Create an associative array of year => count
                $yearCounts = array();
                while ($row = $result->fetch_assoc()) {
                    $yearCounts[$row['passing_year']] = $row['count'];
                }

                // Display folders for all years
                foreach ($years as $year) {
                    $count = isset($yearCounts[$year]) ? $yearCounts[$year] : 0;
                    $folderClass = $count > 0 ? 'folder active' : 'folder empty';
                    
                    echo "<div class='{$folderClass}' onclick='showBatchAlumni({$year})'>
                            <div class='alumni-count'>{$count}</div>
                            <div class='folder-icon'>" . ($count > 0 ? '📁' : '📂') . "</div>
                            <div class='folder-label'>Batch {$year}</div>
                         </div>";
                }
            } catch (Exception $e) {
                echo "Error: " . $e->getMessage();
            }
            ?>
        </div>

        <div class="loading" id="loading">
            Loading alumni data...
        </div>

        <div id="alumni-list" class="alumni-list" style="display: none;">
            <div class="header-actions">
                <h3 id="batch-title"></h3>
                <button class="back-btn" onclick="showBatchFolders()">
                    ← Back to Batches
                </button>
            </div>
            <table class="alumni-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Gender</th>
                        <th>Contact</th>
                        <th>Work Status</th>
                    </tr>
                </thead>
                <tbody id="alumni-data">
                </tbody>
            </table>
        </div>
    </div>

    <script>
    function filterYears() {
        const selection = document.getElementById('yearRange').value;
        const folders = document.querySelectorAll('.folder');
        
        folders.forEach(folder => {
            const year = parseInt(folder.querySelector('.folder-label').textContent.split(' ')[1]);
            
            switch(selection) {
                case 'recent':
                    folder.style.display = (year >= 2020) ? 'flex' : 'none';
                    break;
                case 'older':
                    folder.style.display = (year < 2020) ? 'flex' : 'none';
                    break;
                default:
                    folder.style.display = 'flex';
            }
        });
    }

    function showBatchAlumni(year) {
        const loading = document.getElementById('loading');
        const alumniList = document.getElementById('alumni-list');
        const batchFolders = document.querySelector('.batch-folders');

        loading.style.display = 'block';
        batchFolders.style.display = 'none';
        alumniList.style.display = 'none';

        fetch(`get_batch_alumni.php?year=${year}`)
            .then(response => response.json())
            .then(data => {
                loading.style.display = 'none';
                alumniList.style.display = 'block';
                document.getElementById('batch-title').textContent = `Batch ${year} Alumni`;
                
                const tbody = document.getElementById('alumni-data');
                tbody.innerHTML = '';
                
                if (data.error) {
                    throw new Error(data.error);
                }

                data.forEach(alumni => {
                    tbody.innerHTML += `
                        <tr>
                            <td>${alumni.name}</td>
                            <td>${alumni.email}</td>
                            <td>${alumni.gender}</td>
                            <td>${alumni.contact}</td>
                            <td>${alumni.work_status}</td>
                        </tr>
                    `;
                });
            })
            .catch(error => {
                loading.style.display = 'none';
                console.error('Error:', error);
                alert('An error occurred while fetching alumni data.');
                showBatchFolders();
            });
    }

    function showBatchFolders() {
        document.querySelector('.batch-folders').style.display = 'grid';
        document.getElementById('alumni-list').style.display = 'none';
        document.getElementById('loading').style.display = 'none';
    }

    document.querySelectorAll('.delete-btn').forEach(button => {
        button.addEventListener('click', function() {
            var uid = this.getAttribute('data-uid');
            if (confirm('Are you sure you want to delete this user Id '+ uid )) {
                fetch('', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `delete_id=${uid}`
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('User deleted successfully');
                        this.closest('tr').remove();
                    } else {
                        alert('Error: ' + data.error);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred while deleting the user.');
                });
            }
        });
    });

    function confirmLogout() {
        if (confirm("Are you sure you want to logout?")) {
            fetch('logout.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=logout'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert("You have been successfully logged out.");
                    window.location.href = '../home.php'; 
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert("An error occurred during logout. Please try again.");
            });
        }
    }
    </script>

    <?php include 'footer.php'; ?>
</body>
</html>

