<?php
session_start();
if (!isset($_SESSION['email'])) {
    // Redirect to a different page if not set
    header('Location: ../home.php');
    exit; // Ensure no further code is executed
}
include 'connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $conn->real_escape_string($_POST['id']);
    $title = $conn->real_escape_string($_POST['title']);
    $details =$conn->real_escape_string($_POST['details']);
    $start_date =$conn->real_escape_string( $_POST['start_date']);
    $end_date = $conn->real_escape_string($_POST['end_date']);

    $sql = "UPDATE events SET title=?, details=?, start_date=?, end_date=? WHERE id=?";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param("ssssi", $title, $details, $start_date, $end_date,  $id);

    if ($stmt->execute()) {
       header("Location: events.php?message=Event updated successfully!");
        exit();
    } else {
        $message = "Error: " . $stmt->error;
    }

    $stmt->close();
}

//feach
if (isset($_GET['id'])) {
    $id = $conn->real_escape_string($_GET['id']);
    $sql = "SELECT * FROM events WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    
    // Bind the result variables
    $stmt->bind_result($fetched_id, $fetched_title, $fetched_details, $fetched_start_date, $fetched_end_date);
    
    // Fetch the result
    if ($stmt->fetch()) {
        $event = array( // Changed from [] to array()
            'id' => $fetched_id,
            'title' => $fetched_title,
            'details' => $fetched_details,
            'start_date' => $fetched_start_date,
            'end_date' => $fetched_end_date
        );
    } else {
        die("Event not found.");
    }
    $stmt->close();
} else {
    die("No ID provided.");
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Event</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
     <!-- Update Event Modal -->
     <div id="updateModal" class="modal">
        <div class="modal-content">
            <span class="close" id="closeModal">&times;</span>
            <h2>Update Event</h2>
           
        </div>
    </div>
    
<div class="topnav" id="myTopnav">
    <div class="logo">
        <img src="../image/logo.png" alt="CHARUSAT Logo" style="background-color: white; height: 52px; vertical-align: middle;">
        <span style="vertical-align: middle; ">CE Connect</span>
    </div>
        <div class="topnav-right">
            <a href="index.php">Home</a>
            <a href="alumni.php">Alumni</a>
            <a href="events.php"  class="active">Events</a>
            <a href="jobs.php">Job Post</a>
            <a href="stories.php" >Stories</a>
            <a href="achievements.php" >Achievements</a>
            <!-- <a href="donation.php">Donation</a> -->
            <a href="gallery.php">Gallery</a>
            <a href="help.php">Help</a>
            <a href="profile.php" >Profile</a>
            <a href="#" onclick="confirmLogout()">Logout</a>
            <div class="search-container">
                <input type="text" placeholder="Search...">
                <button type="submit">🔍</button>
            </div>
            <!-- <div class="profile-icon">
                <img src="Profile.jpg" alt="Profile" class="avatar" height="52px">
            </div> -->
        </div>
    </div>
   
    <div class="main-content">
    <div class="header">
    <h2>Update Job Post</h2> 
        </div>
        <form  class="form-table" action="update_event.php" method="POST">
                <input type="hidden" id="id" name="id" value="<?php echo htmlspecialchars($event['id']); ?>">
        <table class="form-table" >
        <tr>
            <td>
                <label for="title">Title of Event:</label>
                <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($event['title']); ?>">
            
                <label for="start_date">Event Starting Date:</label>
                <input type="date" id="start_date" name="start_date" value="<?php echo htmlspecialchars($event['start_date']); ?>">
           
                <label for="end_date">Event Ending Date:</label>
                <input type="date" id="end_date" name="end_date" value="<?php echo htmlspecialchars($event['end_date']); ?>">
            </td>
       
            <td>
                
                <label for="details">Detail Description:</label>
                <textarea  id="details" name="details"><?php echo htmlspecialchars($event['details']); ?></textarea>
                <br><br>
                <div >
                    <button class="btn1">Cancel</button>
                    <button class="btn2">Update Event Post</button>
                </div>
            </td>
          
        </tr>
    </form>


    <script>
    function confirmLogout() {
        if (confirm("Are you sure you want to logout?")) {
            fetch('logout.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=logout'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert("You have been successfully logged out.");
                    window.location.href = '../home.php'; 
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert("An error occurred during logout. Please try again.");
            });
        }
    }
    </script>
</div>
</body>
</html>