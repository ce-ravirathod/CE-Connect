// Main JavaScript file for CE Connect

// DOM Content Loaded Event Listener
document.addEventListener('DOMContentLoaded', function() {
    initializeImageShowcase();
    initializePopup();
    initializeSidebar();
});

// Image Showcase Functionality
function initializeImageShowcase() {
    const slider = document.querySelector('.showcase-slider');
    const prevButton = document.querySelector('.showcase-prev');
    const nextButton = document.querySelector('.showcase-next');
    const slides = document.querySelectorAll('.showcase-image, .showcase-placeholder');
    
    if (!slider || !prevButton || !nextButton || slides.length === 0) return;

    let currentIndex = 0;
    const slideWidth = 100; // 100%

    function showSlide(index) {
        currentIndex = (index + slides.length) % slides.length;
        slider.style.transform = `translateX(-${currentIndex * slideWidth}%)`;
    }

    function nextSlide() {
        showSlide(currentIndex + 1);
    }

    function prevSlide() {
        showSlide(currentIndex - 1);
    }

    nextButton.addEventListener('click', nextSlide);
    prevButton.addEventListener('click', prevSlide);

    // Auto-change slides every 5 seconds
    setInterval(nextSlide, 5000);
}

// Popup Functionality
function initializePopup() {
    const readMoreLinks = document.querySelectorAll('.item-read-more');
    const popupOverlay = document.getElementById('popupOverlay');
    const popupTitle = document.getElementById('popupTitle');
    const popupSubtitle = document.getElementById('popupSubtitle');
    const popupDate = document.getElementById('popupDate');
    const popupContent = document.getElementById('popupContent');
    const closePopup = document.querySelector('.close-popup');

    if (!popupOverlay || !popupTitle || !popupSubtitle || !popupDate || !popupContent || !closePopup) return;

    function openPopup(details) {
        popupOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';

        popupTitle.textContent = details.title;
        popupSubtitle.textContent = details.subtitle;
        popupDate.textContent = details.date;
        popupContent.innerHTML = details.content;
    }

    function closePopupFunction() {
        popupOverlay.classList.remove('active');
        document.body.style.overflow = '';
    }

    readMoreLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const item = this.closest('.view-all-item');
            const fullDetails = {
                title: item.querySelector('.item-title').textContent,
                subtitle: item.querySelector('.item-subtitle').textContent,
                date: item.querySelector('.item-date').textContent,
                content: getFullDetails().content // This function needs to be implemented
            };
            
            openPopup(fullDetails);
        });
    });

    closePopup.addEventListener('click', closePopupFunction);

    popupOverlay.addEventListener('click', function(e) {
        if (e.target === popupOverlay) {
            closePopupFunction();
        }
    });
}

// Sidebar Functionality
function initializeSidebar() {
    const collapseBtn = document.getElementById('collapseBtn');
    const sidebar = document.querySelector('.sidebar');
    const mainContent = document.querySelector('.main-content');

    if (!collapseBtn || !sidebar || !mainContent) return;

    collapseBtn.addEventListener('click', function() {
        sidebar.classList.toggle('collapsed');
        mainContent.classList.toggle('expanded');
        
        if (sidebar.classList.contains('collapsed')) {
            collapseBtn.textContent = '»';
            sidebar.style.width = '60px';
            mainContent.style.marginLeft = '60px';
        } else {
            collapseBtn.textContent = '«';
            sidebar.style.width = '250px';
            mainContent.style.marginLeft = '250px';
        }
    });
}

// Header Menu Toggle Functionality
function toggleMenu() {
    const navMenu = document.querySelector(".header-topnav-right");
    if (navMenu) {
        navMenu.classList.toggle("show");
    }
}

// Placeholder function for getting full details (needs to be implemented)
function getFullDetails() {
    // This function would typically fetch data from a server
    // For this example, we'll return static content
    return {
        title: "New Campus Building Inaugurated",
        subtitle: "State-of-the-art facility opens its doors",
        date: "2023-05-15",
        content: "<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>"
    };
}
