<?php
session_start();
include 'connect.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];

    // Check if the email exists
    $stmt = $conn->prepare("SELECT id, name FROM users WHERE email = ?");
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 1) {
        $stmt->bind_result($id, $name);
        $stmt->fetch();

        // Step 1: Generate random 8-character password
        $new_password = substr(str_shuffle('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, 8);

        // Step 2: Hash the new password (Always hash passwords!)
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

        // Step 3: Update password in database
        $update_stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
        if (!$update_stmt) {
            die("Update prepare failed: " . $conn->error);
        }
        $update_stmt->bind_param("si", $hashed_password, $id);
        $update_stmt->execute();
        $update_stmt->close();

        // Step 4: Send the new password using PHPMailer
        $mail = new PHPMailer(true);

        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com'; // Gmail SMTP server
            $mail->SMTPAuth = true;
            $mail->Username = 'ravi.rathod772001@gmail.com'; // Your Gmail
            $mail->Password = 'sgta ysxv kass fcwr'; // Your Gmail App Password
            $mail->SMTPSecure = 'tls'; // Encryption - SSL or TLS
            $mail->Port = 587; // TCP port to connect to

            // Recipients
            $mail->setFrom('ravi.rathod772001@gmail.com', 'CHARUSAT Alumni Portal');
            $mail->addAddress($email, $name); // Send to user's email

            // Content
            $mail->isHTML(true);
            $mail->Subject = 'Your New Password';
            $mail->Body    = "Hello $name,<br><br>Your new password is: <b>$new_password</b><br><br>Please log in and change it immediately.";
            $mail->AltBody = "Hello $name,\n\nYour new password is: $new_password\n\nPlease log in and change it immediately.";

            $mail->send();
            $success = 'A new password has been sent to your email.';
        } catch (Exception $e) {
            $error = 'Message could not be sent. Mailer Error: ' . $mail->ErrorInfo;
        }

    } else {
        $error = "Email not found.";
    }

    $stmt->close();
    $conn->close();
}

// // Display error or success message
// if(isset($error)) {
//     echo "<p style='color: red;'>$error</p>";
// }
// if(isset($success)) {
//     echo "<p style='color: green;'>$success</p>";
// }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CHARUSAT - Forgot Password</title>
    <link rel="stylesheet" href="login.css">
    <style>
        .required::after {
            content: " *";
            color: red;
        }
    </style>
</head>
<body>
    
    <div class="container">
        <div class="left-panel">
            <div class="logo-circle">
                <img src="images/University_Hero.png" alt="CHARUSAT Logo">
            </div>
        </div>
        <div class="right-panel" >
            <div class="forgot-form">
                <div class="login-logo">
                    <img src="images/logo.png" alt="CHARUSAT Logo">
                </div>
                <h2>Forgot Password</h2>
    <?php if(isset($error)) { echo "<p style='color: red;'>$error</p>"; } ?>
    <?php if(isset($success)) { echo "<p style='color: green;'>$success</p>"; } ?>
    <form action="forgot.php" method="POST">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br><br>
        
        <button type="submit">Send Reset Link</button>
    </form>
            
                <div class="links-container">
                    <div class="login">
                        <a href="login.php">Back to Login</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
