<?php
include '../connect.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: ../home.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$story_id = isset($_GET['id']) ? mysqli_real_escape_string($conn, $_GET['id']) : 0;

// Fetch the story details
$query = "SELECT * FROM alumni_stories WHERE id='$story_id' AND user_id='$user_id' AND status='pending'";
$result = mysqli_query($conn, $query);
$story = mysqli_fetch_assoc($result);

if (!$story) {
    header('Location: stories.php');
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $category = $_POST['category'];
    $story_text = mysqli_real_escape_string($conn, $_POST['story_text']);
    
    $update_query = "UPDATE alumni_stories 
                    SET title='$title', category='$category', description='$story_text' 
                    WHERE id='$story_id' AND user_id='$user_id' AND status='pending'";
    
    if(mysqli_query($conn, $update_query)) {
        header('Location: stories.php');
        exit;
    } else {
        $error = "Error updating story: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Story - Charusat Alumni System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="topnav" id="myTopnav">
    <div class="logo">
        <img src="image/logo.png" alt="CHARUSAT Logo" style="background-color: white; height: 52px; vertical-align: middle;">
        <span style="vertical-align: middle; ">CE Connect</span>
    </div>
        <div class="topnav-right">
            <a href="index.php">Home</a>
            <a href="alumni.php">Alumni</a>
            <a href="events.php">Events</a>
            <a href="jobs.php">Job Post</a>
            <a href="stories.php" class="active">Stories</a>
            <!-- <a href="donation.php">Donation</a> -->
            <a href="achievement.php">Achievements</a>
            <a href="gallery.php">Gallery</a>
            <a href="help.php">Help</a>
            <a href="profile.php" >Profile</a>
            <a href="#" onclick="confirmLogout()">Logout</a>
            <div class="search-container">
                <input type="text" placeholder="Search...">
                <button type="submit">🔍</button>
            </div>
            <!-- <div class="profile-icon">
                <img src="Profile.jpg" alt="Profile" class="avatar" height="52px">
            </div> -->
        </div>
    </div>
    <div class="main-content">
        <div class="header">
            <h2>Edit Story</h2>
        </div>

        <div class="add-job">
            <?php if(isset($error)): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <form action="" method="POST">
                <table class="form-table">
                    <tr>
                        <td>
                            <label for="title">Story Title:</label>
                            <input type="text" id="title" name="title" required 
                                   value="<?php echo htmlspecialchars($story['title']); ?>">
                        </td>
                        <td>
                            <label for="category">Category:</label>
                            <select id="category" name="category" required>
                                <option value="">Select Category</option>
                                <option value="Career" <?php echo ($story['category'] == 'Career') ? 'selected' : ''; ?>>Career</option>
                                <option value="Entrepreneurship" <?php echo ($story['category'] == 'Entrepreneurship') ? 'selected' : ''; ?>>Entrepreneurship</option>
                                <option value="Higher Education" <?php echo ($story['category'] == 'Higher Education') ? 'selected' : ''; ?>>Higher Education</option>
                                <option value="Startup" <?php echo ($story['category'] == 'Startup') ? 'selected' : ''; ?>>Startup</option>
                                <option value="Other" <?php echo ($story['category'] == 'Other') ? 'selected' : ''; ?>>Other</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <label for="story_text">Your Story:</label>
                            <textarea id="story_text" name="story_text" rows="4" required><?php echo htmlspecialchars($story['description']); ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <button type="submit">Update Story</button>
                            <button type="button" onclick="window.location.href='stories.php'">Cancel</button>
                        </td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
</body>
</html> 
<?php include 'footer.php'; ?>