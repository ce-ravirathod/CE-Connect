<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CE Connect - Achievements</title>
    <link rel="stylesheet" href="style.css">
    <link href="../styles/common.css" rel="stylesheet">
    <link href="../styles/home.css" rel="stylesheet">
    <link href="../styles/view_all.css" rel="stylesheet">
    <link href="../styles/header_footer.css" rel="stylesheet">
    <script src="../js/main.js"></script>
 <style>
    .view-all-grid1 {
  /* display: grid; */
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 32px; /* 2rem * 16px */
}
.view-all-title {
    font-size: 40px;
    color: var(--primary-color);
    margin-bottom: 35px;
    text-align: center;
    margin-top: 35px;
}
footer {
            display: flex; /* Use flexbox for alignment */
            justify-content: center; /* Center content horizontally */
            align-items: center; /* Center content vertically */
            text-align: center; /* Center the text */
            padding: 20px; /* Add some padding */
            background-color: #f1f1f1; /* Optional: background color */
            width: 100%; /* Ensure footer takes full width */
            position: relative; /* Ensure proper positioning */
            bottom: 0; /* Stick to the bottom if needed */
        }
 </style>
</head>
<body>

<div class="topnav" id="myTopnav">
    <div class="logo">
        <img src="image/logo.png" alt="CHARUSAT Logo" style="background-color: white; height: 52px; vertical-align: middle;">
        <span style="vertical-align: middle; ">CE Connect</span>
    </div>
        <div class="topnav-right">
            <a href="index.php">Home</a>
            <a href="alumni.php">Alumni</a>
            <a href="events.php">Events</a>
            <a href="jobs.php" >Job Post</a>
            <a href="stories.php" >Stories</a>
            <a href="syllabus.php">Syllabus</a>
            <a href="achievement.php"  class="active">Achievements</a>
            <a href="gallery.php" >Gallery</a>
            <a href="help.php" >Help</a>
            <a href="profile.php" >Profile</a>
            <a  onclick="confirmLogout()">Logout</a>
            <div class="search-container">
                <input type="text" placeholder="Search...">
                <button type="submit">🔍</button>
        </div>
        </div>
    </div>

    <main class="view-all-container">
       
        <h1 class="view-all-title">Achievements</h1>
        
        <div class="view-all-grid1">
            <?php
            // Include the database connection file
            include('connect.php');

            // Fetch achievements from the database
            $sql = "SELECT id, user_id, item_title AS title, item_subtitle AS description, date, category FROM achievements "; // Order by date descending
            $result = $conn->query($sql);

            // Display achievements
            if ($result->num_rows > 0) {
                echo '<div class="achievements-container">'; // Added container for achievements
                while($row = $result->fetch_assoc()) {
                    echo '<div class="view-all-item">'; // Each item will take full grid space
                    echo '<div class="item-type">Achievement</div>'; // This displays by default
                    echo '<h2 class="item-title">' . htmlspecialchars($row["title"]) . '</h2>'; // Title
                    echo '<p class="item-category">' . htmlspecialchars($row["category"]) . '</p>'; // Category
                    echo '<p class="item-date">' . htmlspecialchars($row["date"]) . '</p>'; // Date
                    echo '<p class="item-description">' . htmlspecialchars($row["description"]) . '</p>'; // Description (item_subtitle)
                    echo '<a href="achievement.php" class="item-read-more" onclick="openModal(\'' . addslashes($row["title"]) . '\', \'' . addslashes($row["description"]) . '\', \'' . addslashes($row["date"]) . '\', \'' . addslashes($row["category"]) . '\')">Read More</a>'; // Updated Read More link
                    echo '</div>';
                }
                echo '</div>'; // Close achievements container
            } else {
                echo "No achievements found.";
            }

            $conn->close();
            ?>
        </div>
    </main>

    <div id="popupOverlay" class="popup-overlay">
        <div class="popup-content">
            <span class="close-popup">&times;</span>
            <h2 id="popupTitle"></h2>
            <p id="popupDate"></p>
            <div id="popupContent"></div>
            <p id="popupSubtitle"></p>
        </div>
    </div>
    
 

    <!-- Modal Structure -->
    <div id="achievementModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2 id="modalTitle"></h2>
            <p id="modalCategory"></p>
            <p id="modalDate"></p>
            <p id="modalSubtitle"></p>
            <p id="modalDescription"></p>
        </div>
    </div>

    <script>
        function confirmLogout() {
            if (confirm("Are you sure you want to logout?")) {
                fetch('logout.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'action=logout'
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert("You have been successfully logged out.");
                        window.location.href = '../home.php'; 
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert("An error occurred during logout. Please try again.");
                });
            }
        }

        function openModal(title, description, date, category) {
            document.getElementById('modalTitle').innerText = title;
            document.getElementById('modalSubtitle').innerText = description;
            document.getElementById('modalDate').innerText = date;
            document.getElementById('modalCategory').innerText = category;
            document.getElementById('achievementModal').style.display = 'block';
        }

        function closeModal() {
            document.getElementById('achievementModal').style.display = 'none';
        }

        // Close the modal when clicking outside of it
        window.onclick = function(event) {
            if (event.target == document.getElementById('achievementModal')) {
                closeModal();
            }
        }
    </script>

    <style>
        /* Container for achievements */
        .achievements-container {
            display: flex; /* Use flexbox for layout */
            flex-wrap: wrap; /* Allow items to wrap to the next line */
            justify-content: space-between; /* Space items evenly */
            margin-top: 20px; /* Add margin to the top */
        }

        /* Styles for each achievement item */
        .view-all-item {
            flex: 0 0 30%; /* Each item takes up 30% of the row */
            margin: 10px; /* Add some margin */
            padding: 15px; /* Add padding */
            border: 1px solid #ddd; /* Border for the item */
            border-radius: 8px; /* Rounded corners */
            background-color: #fff; /* Background color */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Subtle shadow */
            transition: transform 0.3s, box-shadow 0.3s; /* Smooth transition for pop effect */
        }

        .view-all-item:hover {
            transform: scale(1.05); /* Scale up on hover */
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2); /* Increase shadow on hover */
        }

        /* Title margin */
        .item-title {
            margin-top: 10px; /* Add margin to the title */
            font-size: 18px; /* Adjust font size */
            color: #333; /* Title color */
        }

        /* Description styles */
        .item-description {
            margin: 5px 0; /* Add margin for spacing */
            color: #555; /* Description color */
        }

        /* Date and category styles */
        .item-date, .item-category {
            font-size: 14px; /* Adjust font size */
            color: #777; /* Color for date and category */
        }

        /* Modal styles */
        .modal {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 1; /* Sit on top */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
            background-color: rgb(0,0,0); /* Fallback color */
            background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
        }

        .modal-content {
            background-color: #fefefe;
            margin: 15% auto; /* 15% from the top and centered */
            padding: 20px;
            border: 1px solid #888;
            width: 80%; /* Could be more or less, depending on screen size */
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
    </style>
</body>
</html>
<?php include('footer.php'); ?>