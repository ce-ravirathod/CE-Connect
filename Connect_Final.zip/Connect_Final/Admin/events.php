<?php
session_start();
if (!isset($_SESSION['email'])) {
    // Redirect to a different page if not set
    header('Location: ../home.php');
    exit; // Ensure no further code is executed
}
include 'connect.php'; // Ensure this file contains your database connection

// Function to fetch event details
function getEvent($id) {
    global $conn; // Use the global connection variable
    $stmt = $conn->prepare("SELECT id, title, start_date, end_date, details FROM events WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

// Function to update event details
function updateEvent($id, $title, $start_date, $end_date, $details) {
    global $conn; // Use the global connection variable
    $stmt = $conn->prepare("UPDATE events SET title = ?, start_date = ?, end_date = ?, details = ? WHERE id = ?");
    $stmt->bind_param("ssssi", $title, $start_date, $end_date, $details, $id);
    return $stmt->execute();
}

// Handle form submission for updating the event
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_id'])) {
    $id = intval($_POST['update_id']);
    $title = $_POST['update_title'];
    $start_date = $_POST['update_date'];
    $end_date = $_POST['update_end_date'];
    $details = $_POST['update_detail'];

    if (updateEvent($id, $title, $start_date, $end_date, $details)) {
        echo json_encode(array('success' => true));
    } else {
        echo json_encode(array('success' => false, 'error' => 'Failed to update event.'));
    }
    exit; // Ensure no further code is executed after handling the request
}

// Handle fetching event details via AJAX
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $event = getEvent($id);
    if ($event) {
        echo json_encode(array('success' => true, 'event' => $event));
    } else {
        echo json_encode(array('success' => false, 'error' => 'Event not found.'));
    }
    exit; // Ensure no further code is executed after handling the request
}

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['delete_id'])) {
        deleteEvent($conn); // Call delete function
    } else {
        insertEvent($conn); // Call insert function
    }
}

function insertEvent($conn) {
    $date = $_POST['date'];
    $end_date = $_POST['end_date']; // Added to capture end date
    $title = $_POST['title'];
    $detail = $_POST['detail'];

    // Prepare and execute the SQL statement
    $stmt = $conn->prepare("INSERT INTO events (title, details, start_date, end_date) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $title, $detail, $date, $end_date); // Added $end_date as parameter

    if ($stmt->execute()) {
        // $_SESSION['message'] = "Event added successfully!";
    } else {
        $_SESSION['message'] = "Error: " . $stmt->error;
    }

    $stmt->close();
    
    // Redirect to prevent form resubmission
    header("Location: ".$_SERVER['PHP_SELF']);
    exit(); // Ensure no further code is executed
}

function deleteEvent($conn) {
    $uid = intval($_POST['delete_id']); // Sanitize input
    $stmt1 = $conn->prepare("DELETE FROM events WHERE id = ?");

    if ($stmt1) {
        $stmt1->bind_param("i", $uid);
        if ($stmt1->execute()) {
            echo json_encode(array('success' => true)); // Return success response
            exit; // Exit after successful deletion
        } else {
            echo json_encode(array('success' => false, 'error' => 'Failed to delete event.')); // Return error response
            exit; // Exit after handling the error
        }
    } else {
        echo json_encode(array('success' => false, 'error' => 'Failed to prepare statement.')); // Return error response
        exit; // Exit after handling the error
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events List</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
   
<div class="topnav" id="myTopnav">
        <div class="logo">
            <img src="../image/logo.png" alt="CHARUSAT Logo" style="background-color: white; height: 52px; vertical-align: middle;">
            <span style="vertical-align: middle;">CE Connect</span>
        </div>
        <div class="topnav-right">
            <a href="index.php">Home</a>
            <a href="alumni.php">Alumni</a>
            <a href="events.php" class="active">Events</a>
            <a href="jobs.php">Job Post</a>
            <a href="stories.php" >Stories</a>
            <a href="achievements.php" >Achievements</a>
            <a href="gallery.php">Gallery</a>
            <a href="help.php">Help</a>
            <a href="profile.php">Profile</a>
            <a href="#" onclick="confirmLogout()">Logout</a>
            <div class="search-container">
                <input type="text" placeholder="Search...">
                <button type="submit">🔍</button>
            </div>
            <!-- <div class="profile-icon">
                <img src="Profile.jpg" alt="Profile" class="avatar" height="52px">
            </div> -->
        </div>
    </div>

    <div class="main-content">
        <div class="header">
            <h2>Add New Event</h2>
        </div>

        <?php
        // Display message if set
        if (isset($_SESSION['message'])) {
            echo "<p class='message'>" . $_SESSION['message'] . "</p>";
            unset($_SESSION['message']);
        }
        ?>

        <!-- Add Event Form -->
        <div class="add-event">
            <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                <table class="form-table">
                    <tr>
                        <td>
                            <label for="title">Title of Event:</label>
                            <input type="text" id="title" name="title" required placeholder="Enter event title">
   
                            <label for="date">Event Starting Date:</label>
                            <input type="date" id="date" name="date" required>
                            <label for="end_date">Event Ending Date:</label> <!-- Updated input name -->
                            <input type="date" id="end_date" name="end_date" required> <!-- Updated input name -->
                        </td>
                        <td>
                            <label for="detail">Detail Description:</label>
                            <textarea id="detail" name="detail" required placeholder="Enter event details"></textarea>
                            
                            <button type="submit">Add Event</button>
                        </td>
                    </tr>
                </table>
            </form>
        </div>

        <!-- Events Display -->
        <div class="events-list">
            <h3>Upcoming Events</h3>
            <table class="events-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Title</th>
                        <th>Details</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Fetch the required data from the events table for upcoming events
                    $sql = "SELECT id, start_date, end_date, title, details FROM events WHERE start_date >= CURDATE() ORDER BY start_date";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $row["id"] . "</td>";
                            echo "<td>" . $row["start_date"] . "</td>";
                            echo "<td>" . $row["end_date"] . "</td>";
                            echo "<td>" . $row["title"] . "</td>";
                            echo "<td style='max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;'>" . $row["details"] . "</td>";
                            echo "<td>
                               <button class='view-btn' data-uid='" . htmlspecialchars($row["id"]) . "'>Update</button>
                            <button class='delete-btn' data-uid='" . htmlspecialchars($row["id"]) . "'>Delete</button></td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='6'>No upcoming events found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>

            <h3>Completed Events</h3>
            <table class="events-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Title</th>
                        <th>Details</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Fetch the required data from the events table for completed events
                    $sql_completed = "SELECT id, start_date, end_date, title, details FROM events WHERE end_date < CURDATE() ORDER BY end_date DESC";
                    $result_completed = $conn->query($sql_completed);

                    if ($result_completed->num_rows > 0) {
                        while($row = $result_completed->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $row["id"] . "</td>";
                            echo "<td>" . $row["start_date"] . "</td>";
                            echo "<td>" . $row["end_date"] . "</td>";
                            echo "<td>" . $row["title"] . "</td>";
                            echo "<td style='max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;'>" . $row["details"] . "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5'>No completed events found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <?php
    $conn->close();
    ?>

    <script>
        function toggleNav() {
            var x = document.getElementById("myTopnav");
            if (x.className === "topnav") {
                x.className += " responsive";
                openNav();
            } else {
                x.className = "topnav";
                closeNav();
            }
        }

        function openNav() {
            document.getElementById("mySidenav").style.width = "250px";
        }

        function closeNav() {
            document.getElementById("mySidenav").style.width = "0";
        }

        function confirmLogout() {
            if (confirm("Are you sure you want to logout?")) {
                fetch('logout.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'action=logout'
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert("You have been successfully logged out.");
                        window.location.href = 'login.php'; 
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert("An error occurred during logout. Please try again.");
                });
            }
        }

        document.querySelectorAll('.delete-btn').forEach(button => {
            button.addEventListener('click', function() {
                var uid = this.getAttribute('data-uid');
                if (confirm('Are you sure you want to delete this event Id '+ uid)) {
                    fetch('', { // Send to the same file
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: `delete_id=${uid}`
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert('Event deleted successfully');
                            location.reload(); // Reload the page after successful deletion
                        } else {
                            alert('Error: ' + data.error);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                    });
                }
            });
        });

        // Open the modal when the update button is clicked
        // Handle update button click
        document.querySelectorAll('.view-btn').forEach(button => {
            button.addEventListener('click', function() {
                const jobId = this.getAttribute('data-uid'); // Get the ID from the data-uid attribute
                // Redirect to the update page
                window.location.href = 'update_event.php?id=' + jobId;
            });
        });

        // Handle update form submission
        document.getElementById('update-form').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent default form submission
            const formData = new FormData(this);
            fetch('update_event.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert("Event updated successfully.");
                    location.reload(); // Reload the page to see the changes
                } else {
                    alert("Error: " + data.error);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert("An error occurred while updating the Event. Please try again.");
            });
        });
    </script>
    <script>
    function confirmLogout() {
        if (confirm("Are you sure you want to logout?")) {
            fetch('logout.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=logout'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert("You have been successfully logged out.");
                    window.location.href = '../home.php'; 
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert("An error occurred during logout. Please try again.");
            });
        }
    }
    </script>

</body>
</html>

<?php include 'footer.php'; ?>