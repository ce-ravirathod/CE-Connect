<?php
include '../connect.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: ../home.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Handle story submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !isset($_POST['delete_id'])) {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $category = $_POST['category'];
    $story_text = mysqli_real_escape_string($conn, $_POST['story_text']);
    
    $query = "INSERT INTO alumni_stories (user_id, title, category, description, status)
              VALUES ('$user_id', '$title', '$category', '$story_text', 'pending')";
    
    if(mysqli_query($conn, $query)) {
        $message = "Story submitted successfully! Awaiting admin approval.";
    } else {
        $message = "Error submitting story: " . mysqli_error($conn);
    }
}

// Handle delete request
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_id'])) {
    $delete_id = mysqli_real_escape_string($conn, $_POST['delete_id']);
    // Add check to ensure the story belongs to the current user
    $delete_query = "DELETE FROM alumni_stories WHERE id='$delete_id' AND user_id='$user_id'";
    
    if(mysqli_query($conn, $delete_query)) {
        echo json_encode(['success' => true]);
        exit;
    } else {
        echo json_encode(['success' => false, 'error' => mysqli_error($conn)]);
        exit;
    }
}

// Fetch user's stories
$query = "SELECT * FROM alumni_stories 
          WHERE user_id='$user_id' 
          ORDER BY created_at DESC";
$user_stories = mysqli_query($conn, $query);

// Fetch all approved stories from all alumni
$all_stories_query = "SELECT s.*, u.name as alumni_name 
                     FROM alumni_stories s 
                     JOIN users u ON s.user_id = u.id 
                     WHERE s.status = 'approved' 
                     ORDER BY s.created_at DESC";
$all_stories = mysqli_query($conn, $all_stories_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alumni Stories - Charusat Alumni System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="topnav" id="myTopnav">
    <div class="logo">
        <img src="image/logo.png" alt="CHARUSAT Logo" style="background-color: white; height: 52px; vertical-align: middle;">
        <span style="vertical-align: middle; ">CE Connect</span>
    </div>
        <div class="topnav-right">
            <a href="index.php">Home</a>
            <a href="alumni.php">Alumni</a>
            <a href="events.php">Events</a>
            <a href="jobs.php">Job Post</a>
            <a href="stories.php" class="active">Stories</a>
            <!-- <a href="donation.php">Donation</a> -->
            <a href="achievement.php">Achievements</a>
            <a href="gallery.php">Gallery</a>
            <a href="help.php">Help</a>
            <a href="profile.php" >Profile</a>
            <a href="#" onclick="confirmLogout()">Logout</a>
            <div class="search-container">
                <input type="text" placeholder="Search...">
                <button type="submit">🔍</button>
            </div>
            <!-- <div class="profile-icon">
                <img src="Profile.jpg" alt="Profile" class="avatar" height="52px">
            </div> -->
        </div>
    </div>

    <div class="main-content">
        <div class="header">
            <h2>Add New Story</h2>
        </div>

        <div class="add-job">
            <?php if(isset($message)): ?>
                <div class="message"><?php echo $message; ?></div>
            <?php endif; ?>
            
            <form id="story-form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                <table class="form-table">
                    <tr>
                        <td>
                            <label for="title">Story Title:</label>
                            <input type="text" id="title" name="title" required placeholder="Enter Story Title">
                        </td>
                        <td>
                            <label for="category">Category:</label>
                            <select id="category" name="category" required>
                                <option value="">Select Category</option>
                                <option value="Career">Career</option>
                                <option value="Entrepreneurship">Entrepreneurship</option>
                                <option value="Higher Education">Higher Education</option>
                                <option value="Startup">Startup</option>
                                <option value="Other">Other</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <label for="story_text">Your Story:</label>
                            <textarea id="story_text" name="story_text" rows="4" required placeholder="Share your story..."></textarea>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <button type="submit" id="insert-btn">Submit Story</button>
                        </td>
                    </tr>
                </table>
            </form>
        </div>

        <div class="jobs-list">
            <h3>My Submitted Stories</h3>
            <table class="jobs-table">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Category</th>
                        <th>Story</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($user_stories)) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['title']); ?></td>
                            <td><?php echo htmlspecialchars($row['category']); ?></td>
                            <td><?php echo htmlspecialchars(substr($row['description'], 0, 50)); ?>...</td>
                            <td class="status-<?php echo strtolower($row['status']); ?>">
                                <?php echo ucfirst($row['status']); ?>
                            </td>
                            <td>
                                <?php if ($row['status'] == 'pending'): ?>
                                    <button class="edit-btn" onclick="editStory(<?php echo $row['id']; ?>)">Edit</button>
                                    <button class="delete-btn" onclick="deleteStory(<?php echo $row['id']; ?>)">Delete</button>
                                <?php elseif ($row['status'] == 'rejected'): ?>
                                    <button class="delete-btn" onclick="deleteStory(<?php echo $row['id']; ?>)">Delete</button>
                                <?php elseif ($row['status'] == 'approved'): ?>
                                    <span class="approved">Approved</span>
                                <?php else: ?>
                                    <span class="no-actions">No Actions</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>

            <h3>All Alumni Stories</h3>
            <table class="jobs-table">
                <thead>
                    <tr>
                        <th>Alumni Name</th>
                        <th>Title</th>
                        <th>Category</th>
                        <th>Story</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($all_stories)) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['alumni_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['title']); ?></td>
                            <td><?php echo htmlspecialchars($row['category']); ?></td>
                            <td><?php echo htmlspecialchars(substr($row['description'], 0, 50)); ?>...</td>
                            <td>
                                <button onclick="openStoryModal('<?php echo htmlspecialchars($row['title']); ?>', '<?php echo htmlspecialchars($row['description']); ?>', '<?php echo htmlspecialchars($row['alumni_name']); ?>')" class="view-btn">View</button>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Add Modal HTML -->
    <div id="storyModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2 id="modalTitle"></h2>
            <p><strong>By: </strong><span id="modalAuthor"></span></p>
            <div id="modalDescription"></div>
        </div>
    </div>

    <!-- Add CSS -->
    <style>
    .modal {
        display: none;
        position: fixed;
        z-index: 1;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgba(0,0,0,0.4);
    }

    .modal-content {
        background-color: #fefefe;
        margin: 15% auto;
        padding: 20px;
        border: 1px solid #888;
        width: 80%;
        max-width: 600px;
        border-radius: 5px;
    }

    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
    }

    .close:hover,
    .close:focus {
        color: black;
        text-decoration: none;
        cursor: pointer;
    }

    .view-btn {
        background-color: #4CAF50;
        color: white;
        padding: 6px 12px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    .view-btn:hover {
        background-color: #45a049;
    }

    #modalDescription {
        margin-top: 20px;
        line-height: 1.6;
        white-space: pre-wrap;
    }
    </style>

    <!-- Add JavaScript -->
    <script>
    var modal = document.getElementById("storyModal");
    var span = document.getElementsByClassName("close")[0];

    function openStoryModal(title, description, author) {
        document.getElementById("modalTitle").textContent = title;
        document.getElementById("modalAuthor").textContent = author;
        document.getElementById("modalDescription").textContent = description;
        modal.style.display = "block";
    }

    // Close modal when clicking the X
    span.onclick = function() {
        modal.style.display = "none";
    }

    // Close modal when clicking outside
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

    // Close modal with Escape key
    document.addEventListener('keydown', function(event) {
        if (event.key === "Escape") {
            modal.style.display = "none";
        }
    });
    </script>

    <script>
    function deleteStory(storyId) {
        if (confirm('Are you sure you want to delete this story?')) {
            const formData = new FormData();
            formData.append('delete_id', storyId);

            fetch('stories.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.reload();
                } else {
                    alert('Error deleting story: ' + (data.error || 'Unknown error'));
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error deleting story. Please try again.');
            });
        }
    }

    function editStory(storyId) {
        window.location.href = 'edit_story.php?id=' + storyId;
    }
    </script>

    <script>
    function confirmLogout() {
        if (confirm("Are you sure you want to logout?")) {
            fetch('logout.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=logout'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert("You have been successfully logged out.");
                    window.location.href = '../home.php'; 
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert("An error occurred during logout. Please try again.");
            });
        }
    }
    </script>
</body>
</html>

<?php include 'footer.php'; ?>