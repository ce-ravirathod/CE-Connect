<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navbar</title>
</head>
<body>
<div class="topnav" id="myTopnav">
        <div class="logo">
            <img src="image/logo.png" alt="CHARUSAT Logo" style="background-color: white; height: 52px; vertical-align: middle;">
            <span style="vertical-align: middle;">CE Connect</span>
        </div>
        <div class="topnav-right">
            <a href="index.php">Home</a>
            <a href="alumni.php">Alumni</a>
            <a href="events.php" class="active">Events</a>
            <a href="jobs.php">Job Post</a>
            <a href="stories.php" >Stories</a>
            <a href="gallery.php">Gallery</a>
            <a href="help.php">Help</a>
            <a href="#" onclick="confirmLogout()">Logout</a>
            <div class="search-container">
                <input type="text" placeholder="Search...">
                <button type="submit">🔍</button>
            </div>
            <div class="profile-icon">
                <img src="Profile.jpg" alt="Profile" class="avatar" height="52px">
            </div>
        </div>
    </div>
</body>
</html>