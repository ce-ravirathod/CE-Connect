<?php
session_start();
if (!isset($_SESSION['email'])) {
    header('Location: ../home.php');
    exit;
}

include 'connect.php';

if (isset($_GET['year'])) {
    $year = intval($_GET['year']);
    
    try {
        $sql = "SELECT email, name, gender, contact, work_status 
                FROM users 
                WHERE user_type = 'alumni' AND passing_year = ?";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $year);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $alumni = array();
        while ($row = $result->fetch_assoc()) {
            $alumni[] = $row;
        }
        
        echo json_encode($alumni);
    } catch (Exception $e) {
        echo json_encode(['error' => $e->getMessage()]);
    }
}
?>
