<?php 
session_start();
if (!isset($_SESSION['email'])) {
    // Redirect to a different page if not set
    header('Location: ../home.php');
    exit; // Ensure no further code is executed
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Help - Charusat Alumni System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="topnav" id="myTopnav">
    <div class="logo">
        <img src="image/logo.png" alt="CHARUSAT Logo" style="background-color: white; height: 52px; vertical-align: middle;">
        <span style="vertical-align: middle; ">CE Connect</span>
    </div>
        <div class="topnav-right">
            <a href="index.php">Home</a>
            <!-- <a href="alumni.php">Alumni</a> -->
            <a href="alumni.php">Alumni</a>
            <a href="events.php">Events</a>
            <a href="jobs.php">Job Post</a>
            <a href="stories.php" >Stories</a>
            <a href="syllabus.php">Syllabus</a>
            <a href="achievement.php">Achievements</a>
            <a href="gallery.php">Gallery</a>
            <a href="help.php" class="active">Help</a>
            <a href="profile.php" >Profile</a>
            <a href="#" onclick="confirmLogout()">Logout</a>
            <div class="search-container">
                <input type="text" placeholder="Search...">
                <button type="submit">🔍</button>
            </div>
            <!-- <div class="profile-icon">
                <img src="Profile.jpg" alt="Profile" class="avatar" height="52px">
            </div> -->
        </div>
    </div>

    <div class="main-content">
        <div class="header">
            <h2>Help and Instructions</h2>
        </div>
        <div class="instruction-container add-job">
            <h3>How to Use the Alumni System</h3>
            
            <div class="instruction-item">
                <h4>1. Home Page Navigation</h4>
                <p>The Home page provides an overview of recent activities, updates, and important announcements. Stay updated with the latest news and events in the alumni community.</p>
            </div>
            
            <div class="instruction-item">
                <h4>2. Events Management</h4>
                <p>The Events section allows you to:
                    <ul>
                        <li>View upcoming alumni events and reunions</li>
                        <li>Register for events</li>
                        <li>Check event details including date, time, and venue</li>
                        <li>View past event galleries</li>
                    </ul>
                </p>
            </div>

            <div class="instruction-item">
                <h4>3. Job Posts</h4>
                <p>In the Job Post section, you can:
                    <ul>
                        <li>Browse available job opportunities</li>
                        <li>Post new job openings</li>
                        <li>Apply for positions</li>
                        <li>Connect with potential employers</li>
                    </ul>
                </p>
            </div>

            <div class="instruction-item">
                <h4>4. Alumni Stories</h4>
                <p>The Stories section features:
                    <ul>
                        <li>Success stories from alumni</li>
                        <li>Share your own journey and experiences</li>
                        <li>Read inspiring stories from fellow alumni</li>
                        <li>Comment and interact with other stories</li>
                    </ul>
                </p>
            </div>

            <div class="instruction-item">
                <h4>5. Achievements</h4>
                <p>In the Achievements section:
                    <ul>
                        <li>View notable alumni achievements</li>
                        <li>Post your own achievements</li>
                        <li>Celebrate community successes</li>
                        <li>Share professional milestones</li>
                    </ul>
                </p>
            </div>

            <div class="instruction-item">
                <h4>6. Gallery</h4>
                <p>The Gallery section contains:
                    <ul>
                        <li>Photos from alumni events</li>
                        <li>Historical images of the institution</li>
                        <li>Community shared photographs</li>
                        <li>Memorable moments from campus life</li>
                    </ul>
                </p>
            </div>

            <div class="instruction-item">
                <h4>7. Profile Management</h4>
                <p>In your Profile section, you can:
                    <ul>
                        <li>Update personal information</li>
                        <li>Change your profile picture</li>
                        <li>Modify contact details</li>
                        <li>Update professional information</li>
                    </ul>
                </p>
            </div>

            <div class="instruction-item">
                <h4>8. Logging Out</h4>
                <p>To ensure your account security:
                    <ul>
                        <li>Click the Logout button when finished</li>
                        <li>Always logout on shared devices</li>
                        <li>Clear browser cache if using a public computer</li>
                    </ul>
                </p>
            </div>
        </div>
    </div>

    <script>
        function toggleNav() {
            var x = document.getElementById("myTopnav");
            if (x.className === "topnav") {
                x.className += " responsive";
                openNav();
            } else {
                x.className = "topnav";
                closeNav();
            }
        }

        function openNav() {
            document.getElementById("mySidenav").style.width = "250px";
        }

        function closeNav() {
            document.getElementById("mySidenav").style.width = "0";
        }
    </script>

    <script>
    function confirmLogout() {
        if (confirm("Are you sure you want to logout?")) {
            fetch('logout.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=logout'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert("You have been successfully logged out.");
                    window.location.href = '../home.php'; 
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert("An error occurred during logout. Please try again.");
            });
        }
    }
    </script>
</body>
</html>

<?php include 'footer.php'; ?>