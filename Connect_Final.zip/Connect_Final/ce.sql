-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 27, 2025 at 09:10 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ce`
--

-- --------------------------------------------------------

--
-- Table structure for table `achievements`
--

CREATE TABLE `achievements` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `item_title` varchar(255) NOT NULL,
  `item_subtitle` text NOT NULL,
  `date` date NOT NULL,
  `category` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `achievements`
--

INSERT INTO `achievements` (`id`, `user_id`, `item_title`, `item_subtitle`, `date`, `category`) VALUES
(5, 1, 'Graduated with Honors', 'Completed my degree with honors in Computer Science.', '2023-05-15', 'Academic'),
(7, 19, 'Marathon Finisher', 'Completed the city marathon in under 4 hours.', '2023-04-20', 'Sports'),
(9, 19, 'Published Research Paper.', 'here Published a research paper in a peer-reviewed journal.', '2025-03-18', 'Research'),
(10, 19, 'First Place in Hackathon', ' Won first place in the annual university hackathon.', '2025-04-27', 'Academic'),
(11, 19, 'Marathon Finisher', ' Completed the city marathon in under 4 hours.', '2025-04-27', 'Sports');

-- --------------------------------------------------------

--
-- Table structure for table `alumni_stories`
--

CREATE TABLE `alumni_stories` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `category` enum('Career','Entrepreneurship','Higher Education','Startup','Other') NOT NULL,
  `description` text NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status_updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `alumni_stories`
--

INSERT INTO `alumni_stories` (`id`, `user_id`, `title`, `category`, `description`, `status`, `created_at`, `status_updated_at`) VALUES
(1, 22, 'career', 'Career', 'i completed my UG.', 'approved', '2025-01-31 08:25:28', '2025-03-18 05:05:19'),
(4, 22, 'career2', 'Career', 'i completed my UG.', 'rejected', '2025-01-31 08:28:18', '2025-03-18 05:05:31'),
(5, 22, 'I get job in google.', 'Other', 'I get job in google and i am happy to get this big achievements.', 'pending', '2025-03-18 05:14:41', NULL),
(6, 19, 'Entrepreneurship Dream', 'Entrepreneurship', '\"My time at CHARUSAT gave me the confidence to start my own startup. Today, I successfully run a tech consultancy firm helping clients across India. The practical exposure during college played a huge role in shaping my entrepreneurial spirit.\"', 'approved', '2025-04-27 05:53:20', '2025-04-27 05:56:23'),
(7, 31, 'Higher Education Abroad', 'Higher Education', 'Thanks to the strong academic foundation from CHARUSAT, I secured admission for my Master\'s at the University of Toronto.', 'approved', '2025-04-27 06:45:15', '2025-04-27 06:50:32'),
(8, 50, 'Cracking Competitive Exams', 'Other', 'After completing my UG, I cleared GATE with an excellent rank and got admission to IIT Bombay.', 'approved', '2025-04-27 06:46:00', '2025-04-27 06:50:01'),
(9, 9, 'Corporate Success', 'Career', 'Within two years of joining a reputed IT firm, I was promoted to Project Manager.', 'pending', '2025-04-27 06:46:30', NULL),
(10, 100, 'Starting My NGO', 'Entrepreneurship', 'Inspired by my time at CHARUSAT, I founded a non-profit to educate underprivileged children.', 'approved', '2025-04-27 06:46:58', '2025-04-27 06:50:23'),
(11, 22, 'Published Research Paper', 'Other', 'During my final year, I published a research paper in an international journal, thanks to the excellent guidance of my faculty.', 'approved', '2025-04-27 06:47:35', '2025-04-27 06:50:06'),
(12, 30, 'From Intern to CEO', 'Career', 'Starting as an intern during my final year, I now lead a fast-growing tech company. CHARUSAT prepared me for real-world challenges.', 'pending', '2025-04-27 06:48:58', NULL),
(13, 29, 'Tech Innovation Award', 'Other', 'Our college project turned into a product that won the National Tech Innovation Award!', 'approved', '2025-04-27 06:48:58', '2025-04-27 06:50:28'),
(14, 23, 'Scholarship to Stanford', 'Higher Education', 'I received a full scholarship to Stanford University for my Master\'s degree, thanks to the strong research experience at CHARUSAT.', 'pending', '2025-04-27 06:49:53', NULL),
(15, 35, 'Launched a Mobile App', 'Entrepreneurship', 'I launched a mobile app during my final semester, which crossed 50,000 downloads within the first 6 months!', 'pending', '2025-04-27 06:49:53', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `details` text DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `details`, `start_date`, `end_date`) VALUES
(1, 'Alumni Meetup', 'Annual meetup of all alumni at the university campus. Join us for networking, workshops, and a trip down memory lane.', '2024-10-08', '2024-10-09'),
(2, 'Career Fair', 'Connect with potential employers and explore job opportunities. Bring your resume and be ready to impress! employers and explore job opportunities.', '2024-10-10', '2024-10-17'),
(5, 'Spring Reunion', 'Welcome back to campus! Join fellow alumni for a day of activities, campus tours, and catching up with old friends.', '2024-10-11', '2024-10-12'),
(7, 'Summer Networking Mixer', 'Beat the heat with cool connections! Join us for an evening of networking and refreshments with fellow alumni.', '2024-10-06', '2024-10-07'),
(15, 'Navratri', 'Garba is going...                  ', '2024-10-03', '2024-10-12'),
(16, 'qqw', '1223', '2024-10-09', '2024-10-12'),
(18, 'qwe', 'asdfghjkl', '2024-10-13', '2024-10-15'),
(19, 'Homecoming Weekend', 'Celebrate homecoming with a parade, games, and alumni gatherings!', '2024-10-15', '2024-10-16'),
(20, 'Fall Fest', 'Join us for food, music, and fun activities on the quad!', '2024-10-20', '2024-10-20'),
(21, 'Campus Sustainability Day', 'Workshops and panels on sustainability practices on campus.', '2024-10-22', '2024-10-22'),
(22, 'Halloween Costume Contest', 'Dress up and participate in our annual costume competition!', '2024-10-25', '2024-10-25'),
(23, 'Diwali Celebration', 'Experience the festival of lights with cultural performances and food!', '2024-10-28', '2024-10-30'),
(24, 'Guest Speaker Series', 'Join us for an inspiring talk by a distinguished alumnus!', '2024-11-01', '2024-11-01'),
(25, 'Research Symposium', 'Showcase of student research projects and innovative ideas.', '2024-11-05', '2024-11-05'),
(26, 'Winter Sports Fair', 'Learn about winter sports clubs and activities on campus.', '2024-11-10', '2024-11-10'),
(27, 'Thanksgiving Potluck', 'Bring a dish to share and enjoy a meal with the campus community!', '2024-11-15', '2024-11-15'),
(28, 'Art Exhibition Opening', 'Opening night for student art exhibition—come support your peers!', '2024-11-20', '2024-11-20'),
(29, 'Finals Prep Workshop', 'Tips and strategies to ace your finals—open to all students!', '2024-11-25', '2024-11-25'),
(30, 'Winter Wonderland', 'Enjoy festive decorations, activities, and holiday spirit on campus!', '2024-12-01', '2024-12-01'),
(31, 'Community Service Day', 'Volunteer for various local organizations and give back!', '2024-12-05', '2024-12-05'),
(32, 'Holiday Talent Show', 'Showcase your talent and enjoy performances from fellow students!', '2024-12-10', '2024-12-10'),
(33, 'End-of-Semester Bash', 'Celebrate the end of the semester with food, music, and fun!', '2024-12-15', '2024-12-15'),
(34, 'Holiday Talent Show', 'Holiday Talent Show is their...', '2025-03-17', '2025-03-19'),
(35, 'End-of-Semester Bash.', 'Celebrate the end of the semester with food, music, and fun...', '2025-03-20', '2025-04-10'),
(36, 'Career Fair', 'Connect with potential employers and explore job opportunities...', '2025-04-02', '2025-04-11'),
(37, 'Holiday Talent Show', 'Showcase your talent and enjoy performances from fellow students!', '2025-04-02', '2025-04-07'),
(38, 'Alumni Meetup', 'Annual meetup of all alumni at the university campus. ', '2025-04-29', '2025-04-30');

-- --------------------------------------------------------

--
-- Table structure for table `get_in_touch`
--

CREATE TABLE `get_in_touch` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `get_in_touch`
--

INSERT INTO `get_in_touch` (`id`, `name`, `email`, `phone`, `message`, `created_at`) VALUES
(1, 'Rahul Patel', 'rahul.patel@example.com', '9876543210', 'I would like to know more about alumni events.', '2025-04-27 07:01:02'),
(2, 'Sneha Mehta', 'sneha.mehta@example.com', '9876501234', 'How can I update my alumni profile?', '2025-04-27 07:01:02'),
(3, 'Amit Shah', 'amit.shah@example.com', '9876512345', 'I want to share my success story with CHARUSAT.', '2025-04-27 07:01:02'),
(4, 'Pooja Desai', 'pooja.desai@example.com', '9876523456', 'Interested in mentoring current students.', '2025-04-27 07:01:02'),
(5, 'Viral Thakkar', 'viral.thakkar@example.com', '9876534567', 'Having trouble accessing the alumni portal.', '2025-04-27 07:01:02'),
(6, 'Ravi Rathod', 'ravi.ce@gmail.com', '9313573610', 'I want to connect.', '2025-04-27 07:03:56');

-- --------------------------------------------------------

--
-- Table structure for table `job_posts`
--

CREATE TABLE `job_posts` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `job_type` enum('Full Time','Part Time','Internship') NOT NULL,
  `requirements` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `job_posts`
--

INSERT INTO `job_posts` (`id`, `date`, `company_name`, `job_type`, `requirements`) VALUES
(3, '2024-06-11', 'Tech Innovators', 'Internship', 'Looking for enthusiastic computer science students for summer internship'),
(4, '2024-06-12', 'Global Solutions', 'Full Time', 'Senior project manager needed for our IT department'),
(8, '2023-10-05', 'Green Energy Solutions', 'Full Time', 'Experience in renewable energy projects, strong communication skills.'),
(9, '2023-10-10', 'Global Marketing Agency', 'Internship', 'Currently pursuing a degree in Marketing or related field, excellent writing skills.'),
(10, '2023-10-15', 'HealthCare Plus', 'Part Time', 'Registered Nurse with at least 2 years of experience, strong patient care skills.'),
(11, '2023-10-20', 'Finance Corp', 'Part Time', 'Degree in Finance or Accounting, proficiency in Excel and financial modeling.'),
(30, '2024-10-09', 'abcd11', 'Full Time', '12 devloper 12 employees '),
(32, '2024-10-11', 'Divine Infosys', 'Internship', '42 developer '),
(34, '2024-10-12', 'Divine Infosys111', 'Internship', '34 student requests '),
(35, '2024-10-13', 'qwe11', 'Part Time', '122'),
(36, '2024-10-13', 'Infosys', 'Part Time', '123 dev'),
(37, '2024-10-13', 'Tech Solutions Inc.', 'Part Time', 'Flexible hours, must be a team player.'),
(38, '2024-10-14', 'Innovative Designs', 'Internship', 'Seeking creative minds for design internship.'),
(39, '2024-10-15', 'Future Tech Corp.', 'Full Time', 'Experience in software development, team collaboration skills required.'),
(40, '2024-10-16', 'Eco-Friendly Enterprises', 'Part Time', 'Passion for sustainability, strong communication skills.'),
(41, '2024-10-17', 'Health Innovations', 'Internship', 'Must be pursuing a degree in Health Sciences or related field.'),
(42, '2024-10-18', 'Global Finance Ltd.', 'Full Time', 'Degree in Finance, strong analytical skills required.'),
(43, '2024-10-19', 'Digital Marketing Agency', 'Internship', 'Currently pursuing a degree in Marketing or related field.'),
(44, '2024-10-20', 'Consulting Services Group', 'Part Time', 'Excellent organizational skills, customer service experience preferred.'),
(45, '2024-10-21', 'Creative Media House', 'Full Time', 'Experience in content creation and social media management.'),
(46, '2024-10-22', 'Data Analytics Corp.', 'Internship', 'Pursuing a degree in Data Science or Statistics, strong analytical skills.'),
(48, '2024-10-24', 'Web Development Agency', 'Full Time', 'Proficient in HTML, CSS, and JavaScript, portfolio required.'),
(49, '2024-10-25', 'Logistics Services', 'Internship', 'Seeking logistics or supply chain students for summer internship.'),
(50, '2024-10-26', 'Retail Solutions', 'Part Time', 'Strong customer service skills, flexible schedule preferred.'),
(51, '2024-10-27', 'Finance Experts', 'Full Time', 'Experience in financial analysis, degree in Finance or related field required.'),
(53, '2025-03-18', 'Data Analytics Corp.', 'Part Time', 'Pursuing a degree in Data Science or Statistics, strong analytical skills.'),
(54, '2025-04-27', 'Global Tech Solutions', 'Part Time', 'Web developer'),
(55, '2025-04-26', 'Logistics Services', 'Internship', 'Experience in tech support, excellent communication skills.');

-- --------------------------------------------------------

--
-- Table structure for table `stories`
--

CREATE TABLE `stories` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stories`
--

INSERT INTO `stories` (`id`, `date`, `title`, `description`, `created_at`) VALUES
(1, '2024-03-15', 'Success in Silicon Valley', 'Our alumni John Doe landed a leadership position at a major tech company Success in Silicon Valley. landed a leadership position at a major tech.', '2024-12-27 09:22:48'),
(2, '2024-03-10', 'Startup Success Story', 'Alumni Jane Smith launched her successful AI startup this is my Startup Success. and launched her successful AI startup.', '2024-12-27 09:22:48'),
(3, '2024-03-05', 'Innovation Award Winner', 'CSPIT alumnus wins prestigious innovation award for breakthrough research Innovation Award Winner alumnus wins prestigious innovation.', '2024-12-27 09:22:48');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` enum('Male','Female','Other') DEFAULT NULL,
  `college_id` varchar(255) DEFAULT NULL,
  `contact` varchar(15) NOT NULL,
  `passing_year` year(4) NOT NULL,
  `work_status` enum('Unemployed','Employed','Student','Retired') DEFAULT NULL,
  `profile_photo` varchar(255) DEFAULT NULL,
  `user_type` enum('student','alumni','admin') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `name`, `date_of_birth`, `gender`, `college_id`, `contact`, `passing_year`, `work_status`, `profile_photo`, `user_type`) VALUES
(1, 'ravi.rathod772001@gmail.com', '$2y$10$xCUA8hWKK2SauCMdgxigbeNoWXIY48ow5iuuc8F6VC7x6Gsal.YcW', 'Ravi', '2004-12-09', 'Male', 'Not for Admin', '9313573610', '2021', 'Unemployed', NULL, 'admin'),
(3, 'mike.johnson@example.com', 'mikepass', 'Mike Johnson', '1990-04-12', 'Male', 'D19CE123', '9876543210', '2012', 'Employed', 'mike_profile.jpg', 'alumni'),
(4, 'sara.connor@example.com', 'sarapass', 'Sara Connor', '1995-07-22', 'Female', NULL, '8765432109', '2016', 'Unemployed', 'sara_profile.jpg', 'student'),
(5, 'tom.hanks@example.com', 'tomhanks123', 'Tom Hanks', '1988-11-30', 'Male', '18CE145', '7654321098', '2010', 'Employed', 'tom_profile.jpg', 'alumni'),
(6, 'lisa.white@example.com', 'lisapass', 'Lisa White', '1992-09-15', 'Female', NULL, '6543210987', '2014', 'Student', 'lisa_profile.jpg', 'student'),
(8, 'john.doe@example.com', '123', 'John Doe', '1990-05-15', 'Male', NULL, '1234567890', '2012', 'Employed', NULL, 'alumni'),
(9, 'jane.smith@example.com', '123', 'Jane Smith', NULL, 'Female', NULL, '0987654321', '2014', 'Unemployed', NULL, 'alumni'),
(19, 'admin.ce@gmail.com', '$2y$10$vLpABIlrSsx8H4L5viz4zuZUxEQsKD1NrnbujudsMrU.Ayn/efgM.', 'Ravi Rathod M...', '2004-12-10', 'Male', 'Not for Admin', '9876543212', '2016', 'Employed', 'photo1.png', 'admin'),
(21, 'student.ce@gmail.com', '$2y$10$vLpABIlrSsx8H4L5viz4zuZUxEQsKD1NrnbujudsMrU.Ayn/efgM.', 'kishan ', '2025-03-19', 'Male', 'd23ce170', '9876543210', '2011', 'Employed', 'users/d23ce170.jpg', 'student'),
(22, 'alumni.ce@gmail.com', '$2y$10$wGLRaHxKfDPJc5phbMeMeetimAspPpXmhPSDGOIafQw5BEGgN2Jeu', 'Vimal Rathod', '2004-07-07', 'Male', 'D21CE142', '9876543211', '2016', 'Employed', 'photo2.png', 'alumni'),
(23, 'tirthraj123@gmail.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Tirthraj bhai ', '2004-03-05', 'Male', NULL, '9863576310', '2023', 'Student', NULL, 'student'),
(24, 'alice.wonderland@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Alice Wonderland', '1995-06-01', 'Female', 'd23ce001', '1234567890', '2017', 'Employed', 'alice_profile.jpg', 'alumni'),
(25, 'bob.builder@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Bob Builder', '1989-03-15', 'Male', 'd10ce002', '2345678901', '2010', 'Unemployed', 'bob_profile.jpg', 'alumni'),
(26, 'charlie.brown@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Charlie Brown', '1992-07-21', 'Male', 'd13ce003', '3456789012', '2013', 'Student', 'charlie_profile.jpg', 'student'),
(27, 'daisy.duck@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Daisy Duck', '1994-11-05', 'Female', 'd16ce004', '4567890123', '2016', 'Retired', 'daisy_profile.jpg', 'alumni'),
(28, 'edward.elric@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Edward Elric', '1990-09-18', 'Male', 'd12ce005', '5678901234', '2012', 'Employed', 'edward_profile.jpg', 'alumni'),
(29, 'frank.franklin@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Frank Franklin', '1985-12-25', 'Male', 'd08ce006', '6789012345', '2008', 'Unemployed', 'frank_profile.jpg', 'student'),
(30, 'grace.hopper@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Grace Hopper', '1987-05-01', 'Female', 'd09ce007', '7890123456', '2009', 'Student', 'grace_profile.jpg', 'alumni'),
(31, 'harry.potter@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Harry Potter', '1980-07-31', 'Male', 'd00ce008', '8901234567', '2024', 'Employed', 'harry_profile.jpg', 'alumni'),
(32, 'isabelle.lee@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Isabelle Lee', '1998-02-14', 'Female', 'd22ce009', '9012345678', '2022', 'Student', 'isabelle_profile.jpg', 'student'),
(34, 'kate.bush@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Kate Bush', '1993-08-30', 'Female', 'd15ce011', '1234567890', '2024', 'Employed', 'kate_profile.jpg', 'alumni'),
(35, 'mona.lisa@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Mona Lisa', '1503-06-01', 'Female', 'd1503c012', '2345678901', '2024', 'Retired', 'mona_profile.jpg', 'alumni'),
(36, 'nina.simone@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Nina Simone', '1933-02-21', 'Female', 'd50ce013', '4567890123', '2023', 'Unemployed', 'nina_profile.jpg', 'alumni'),
(37, 'oscar.wilde@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Oscar Wilde', '1854-10-16', 'Male', 'd70ce014', '5678901234', '2024', 'Employed', 'oscar_profile.jpg', 'alumni'),
(38, 'peter.parker@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Peter Parker', '1995-05-01', 'Male', 'd17ce015', '6789012345', '2017', 'Student', 'peter_profile.jpg', 'student'),
(39, 'quinn.martin@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Quinn Martin', '1999-11-11', 'Female', 'd21ce016', '7890123456', '2021', 'Retired', 'quinn_profile.jpg', 'alumni'),
(40, 'ron.weasley@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Ron Weasley', '1980-03-01', 'Male', 'd00ce017', '8901234567', '2000', 'Employed', 'ron_profile.jpg', 'alumni'),
(41, 'susan.sarandon@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Susan Sarandon', '1946-10-04', 'Female', 'd65ce018', '9012345678', '1965', 'Retired', 'susan_profile.jpg', 'alumni'),
(42, 'tony.stark@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Tony Stark', '1970-05-29', 'Male', 'd92ce019', '0123456789', '1992', 'Employed', 'tony_profile.jpg', 'alumni'),
(43, 'uma.thurman@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Uma Thurman', '1970-04-29', 'Female', 'd95ce020', '1234567890', '1995', 'Student', 'uma_profile.jpg', 'student'),
(44, 'victor.frankl@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Victor Frankl', '1905-03-26', 'Male', 'd28ce021', '2345678901', '1928', 'Retired', 'victor_profile.jpg', 'alumni'),
(45, 'william.shakespeare@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'William Shakespeare', '1564-04-26', 'Male', 'd58ce022', '3456789012', '0000', 'Unemployed', 'will_profile.jpg', 'student'),
(46, 'xena.warrior@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Xena Warrior', '1975-03-15', 'Female', 'd96ce023', '4567890123', '1996', 'Student', 'xena_profile.jpg', 'student'),
(47, 'yoda.master@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Yoda Master', '0896-02-01', 'Male', 'd00ce024', '5678901234', '0000', 'Retired', 'yoda_profile.jpg', 'alumni'),
(48, 'zara.hadid@example.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Zara Hadid', '1950-10-31', 'Female', 'd75ce025', '6789012345', '1975', 'Employed', 'zara_profile.jpg', 'alumni'),
(49, 'rushi@gmail.com', '$2y$10$TV4E2hkDMu2CuAkqYGTGJ.8.FEKV2i7WJ/e92hWcYWjh/C/BwgC1S', 'Rushi', NULL, NULL, NULL, '7845568948', '2023', NULL, NULL, 'alumni'),
(50, 'anandc1@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'Kishan B', '2011-02-01', 'Male', 'd23ce170', '9876543210', '2011', 'Student', 'photo3.png', 'alumni'),
(51, 'ravirathod1@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'Vimal Rathod', '2004-07-07', 'Male', 'D21CE142', '9876543211', '2016', 'Employed', 'photo2.png', 'alumni'),
(52, 'user3@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Three', '2005-01-01', 'Female', 'D21CE143', '9876543212', '2015', 'Employed', 'photo1.png', 'alumni'),
(53, 'user4@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Four', '2006-02-02', 'Male', 'D21CE144', '9876543213', '2016', 'Employed', 'photo1.png', 'alumni'),
(54, 'user5@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Five', '2007-03-03', 'Female', 'D21CE145', '9876543214', '2017', 'Employed', 'photo1.png', 'alumni'),
(55, 'user6@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Six', '2008-04-04', 'Male', 'D21CE146', '9876543215', '2018', 'Employed', 'photo1.png', 'alumni'),
(56, 'user7@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Seven', '2009-05-05', 'Female', 'D21CE147', '9876543216', '2019', 'Employed', 'photo1.png', 'alumni'),
(57, 'user8@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Eight', '2010-06-06', 'Male', 'D21CE148', '9876543217', '2020', 'Employed', 'photo1.png', 'alumni'),
(58, 'user9@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Nine', '2011-07-07', 'Female', 'D21CE149', '9876543218', '2021', 'Employed', 'photo1.png', 'alumni'),
(59, 'user10@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Ten', '2012-08-08', 'Male', 'D21CE150', '9876543219', '2022', 'Employed', 'photo1.png', 'alumni'),
(60, 'user11@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Eleven', '2013-09-09', 'Female', 'D21CE151', '9876543220', '2023', 'Employed', 'photo1.png', 'alumni'),
(61, 'user12@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Twelve', '2014-10-10', 'Male', 'D21CE152', '9876543221', '2024', 'Employed', 'photo1.png', 'alumni'),
(62, 'user13@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Thirteen', '2015-11-11', 'Female', 'D21CE153', '9876543222', '2025', 'Employed', 'photo1.png', 'alumni'),
(63, 'user14@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Fourteen', '2016-12-12', 'Male', 'D21CE154', '9876543223', '2026', 'Employed', 'photo1.png', 'alumni'),
(64, 'user15@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Fifteen', '2017-01-13', 'Female', 'D21CE155', '9876543224', '2027', 'Employed', 'photo1.png', 'alumni'),
(65, 'user16@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Sixteen', '2018-02-14', 'Male', 'D21CE156', '9876543225', '2028', 'Employed', 'photo1.png', 'alumni'),
(66, 'user17@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Seventeen', '2019-03-15', 'Female', 'D21CE157', '9876543226', '2029', 'Employed', 'photo1.png', 'alumni'),
(67, 'user18@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Eighteen', '2020-04-16', 'Male', 'D21CE158', '9876543227', '2030', 'Employed', 'photo1.png', 'alumni'),
(68, 'user19@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Nineteen', '2021-05-17', 'Female', 'D21CE159', '9876543228', '2031', 'Employed', 'photo1.png', 'alumni'),
(69, 'user20@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Twenty', '2022-06-18', 'Male', 'D21CE160', '9876543229', '2032', 'Employed', 'photo1.png', 'alumni'),
(70, 'user21@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Twenty-One', '2023-07-19', 'Female', 'D21CE161', '9876543230', '2033', 'Employed', 'photo1.png', 'alumni'),
(71, 'user22@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Twenty-Two', '2024-08-20', 'Male', 'D21CE162', '9876543231', '2034', 'Employed', 'photo1.png', 'alumni'),
(72, 'user23@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Twenty-Three', '2025-09-21', 'Female', 'D21CE163', '9876543232', '2035', 'Employed', 'photo1.png', 'alumni'),
(73, 'user24@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Twenty-Four', '2026-10-22', 'Male', 'D21CE164', '9876543233', '2036', 'Employed', 'photo1.png', 'alumni'),
(74, 'user25@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Twenty-Five', '2027-11-23', 'Female', 'D21CE165', '9876543234', '2037', 'Employed', 'photo1.png', 'alumni'),
(75, 'user26@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Twenty-Six', '2028-12-24', 'Male', 'D21CE166', '9876543235', '2038', 'Employed', 'photo1.png', 'alumni'),
(76, 'user27@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Twenty-Seven', '2029-01-25', 'Female', 'D21CE167', '9876543236', '2039', 'Employed', 'photo1.png', 'alumni'),
(77, 'user28@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Twenty-Eight', '2030-02-26', 'Male', 'D21CE168', '9876543237', '2040', 'Employed', 'photo1.png', 'alumni'),
(78, 'user29@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Twenty-Nine', '2031-03-27', 'Female', 'D21CE169', '9876543238', '2041', 'Employed', 'photo1.png', 'alumni'),
(79, 'user30@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Thirty', '2032-04-28', 'Male', 'D21CE170', '9876543239', '2042', 'Employed', 'photo1.png', 'alumni'),
(80, 'user31@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Thirty-One', '2033-05-29', 'Female', 'D21CE171', '9876543240', '2043', 'Employed', 'photo1.png', 'alumni'),
(81, 'user32@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Thirty-Two', '2034-06-30', 'Male', 'D21CE172', '9876543241', '2044', 'Employed', 'photo1.png', 'alumni'),
(82, 'user33@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Thirty-Three', '2035-07-31', 'Female', 'D21CE173', '9876543242', '2045', 'Employed', 'photo1.png', 'alumni'),
(83, 'user34@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Thirty-Four', '2036-08-01', 'Male', 'D21CE174', '9876543243', '2046', 'Employed', 'photo1.png', 'alumni'),
(84, 'user35@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Thirty-Five', '2037-09-02', 'Female', 'D21CE175', '9876543244', '2047', 'Employed', 'photo1.png', 'alumni'),
(85, 'user36@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Thirty-Six', '2038-10-03', 'Male', 'D21CE176', '9876543245', '2048', 'Employed', 'photo1.png', 'alumni'),
(86, 'user37@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Thirty-Seven', '2039-11-04', 'Female', 'D21CE177', '9876543246', '2049', 'Employed', 'photo1.png', 'alumni'),
(87, 'user38@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Thirty-Eight', '2040-12-05', 'Male', 'D21CE178', '9876543247', '2050', 'Employed', 'photo1.png', 'alumni'),
(88, 'user39@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Thirty-Nine', '2041-01-06', 'Female', 'D21CE179', '9876543248', '2051', 'Employed', 'photo1.png', 'alumni'),
(89, 'user40@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Forty', '2042-02-07', 'Male', 'D21CE180', '9876543249', '2052', 'Employed', 'photo1.png', 'alumni'),
(90, 'user41@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Forty-One', '2043-03-08', 'Female', 'D21CE181', '9876543250', '2053', 'Employed', 'photo1.png', 'alumni'),
(91, 'user42@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Forty-Two', '2044-04-09', 'Male', 'D21CE182', '9876543251', '2054', 'Employed', 'photo1.png', 'alumni'),
(92, 'user43@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Forty-Three', '2045-05-10', 'Female', 'D21CE183', '9876543252', '2055', 'Employed', 'photo1.png', 'alumni'),
(93, 'user44@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Forty-Four', '2046-06-11', 'Male', 'D21CE184', '9876543253', '2056', 'Employed', 'photo1.png', 'alumni'),
(94, 'user45@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Forty-Five', '2047-07-12', 'Female', 'D21CE185', '9876543254', '2057', 'Employed', 'photo1.png', 'alumni'),
(95, 'user46@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Forty-Six', '2048-08-13', 'Male', 'D21CE186', '9876543255', '2058', 'Employed', 'photo1.png', 'alumni'),
(96, 'user47@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Forty-Seven', '2049-09-14', 'Female', 'D21CE187', '9876543256', '2059', 'Employed', 'photo1.png', 'alumni'),
(97, 'user48@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Forty-Eight', '2050-10-15', 'Male', 'D21CE188', '9876543257', '2060', 'Employed', 'photo1.png', 'alumni'),
(98, 'user49@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Forty-Nine', '2051-11-16', 'Female', 'D21CE189', '9876543258', '2061', 'Employed', 'photo1.png', 'alumni'),
(99, 'user50@email.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e99...', 'User Fifty', '2052-12-17', 'Male', 'D21CE190', '9876543259', '2062', 'Employed', 'photo1.png', 'alumni'),
(100, 'cpp@gmail.com', '$2y$10$FonizYxM.ci2o7.Rus89R.M2Vx453pqsnU.lLunwl6zpN4SF9mp.S', 'C++', NULL, NULL, NULL, '7574019129', '2016', NULL, NULL, 'alumni'),
(101, 'email0@email.com', '$2y$10$NomcCs3bqyYorOqYhxSp0ujsmJCW/nRJ9xFQrlmi9Y.BRkw31cVOG', 'Ravi Rathod M.', NULL, NULL, NULL, '9876543212', '2012', NULL, NULL, 'student'),
(102, 'email2112@email.com', '$2y$10$DrsS11yeY2m09S2lJmjORunls1XU7ZePpW8c1bwaAELRpLniNzTZa', 'Ravi Rathod M.', NULL, NULL, NULL, '7574019129', '2007', NULL, NULL, 'alumni'),
(103, 'email012@email.com', '$2y$10$/8b1EPh6N37ByGU5ShJHxe77yyjAHWzR0OGy/oswFSiHd6/MUlymK', 'Kashyap', NULL, NULL, NULL, '9727731762', '2010', NULL, NULL, 'student'),
(104, 'prayag@gmail.com', '$2y$10$FTipIZKSh5a4fOW8kTpKuuRkd92BqfB/y2zjrz8udzFMEv5ZjK2We', 'Prayag Parmar', NULL, NULL, NULL, '7574019156', '2014', NULL, NULL, 'alumni'),
(105, 'ravirathod.divineinfosys@gmail.com', '$2y$10$thWrLra/C6NWL4Iqc/UohuCWhTuf6YTnAGGuRRViPIpKzjbRwSlPu', 'Anand Chaniyara', '2025-04-15', 'Male', 'D21CE142', '7574019129', '2015', 'Employed', 'photo1.png', 'alumni'),
(106, 'ravirathod.ce@gmail.com', '$2y$10$ClTtgGMKWKFtvYdc8N07IOmxvYJfXoNFZFlTwUFhfEIDBqSgZQyli', 'Kashyap', '2006-06-14', 'Male', '12CE142', '9876543212', '2018', 'Unemployed', NULL, 'alumni');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `achievements`
--
ALTER TABLE `achievements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `alumni_stories`
--
ALTER TABLE `alumni_stories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `get_in_touch`
--
ALTER TABLE `get_in_touch`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job_posts`
--
ALTER TABLE `job_posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stories`
--
ALTER TABLE `stories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `achievements`
--
ALTER TABLE `achievements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `alumni_stories`
--
ALTER TABLE `alumni_stories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `get_in_touch`
--
ALTER TABLE `get_in_touch`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `job_posts`
--
ALTER TABLE `job_posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `stories`
--
ALTER TABLE `stories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `achievements`
--
ALTER TABLE `achievements`
  ADD CONSTRAINT `achievements_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `alumni_stories`
--
ALTER TABLE `alumni_stories`
  ADD CONSTRAINT `alumni_stories_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
