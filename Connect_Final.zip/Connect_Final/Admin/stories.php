<?php
include '../connect.php';
session_start();

// Add error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Verify admin access
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../home.php');
    exit;
}

// Handle story approval/rejection
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $story_id = isset($_POST['story_id']) ? (int)$_POST['story_id'] : 0;
        $action = isset($_POST['action']) ? $_POST['action'] : '';
        
        if ($story_id && ($action == 'approve' || $action == 'reject')) {
            $status = ($action == 'approve') ? 'approved' : 'rejected';
            
            // Simple query first to check if story exists
            $check_query = "SELECT id FROM alumni_stories WHERE id = ?";
            if($check_stmt = $conn->prepare($check_query)) {
                $check_stmt->bind_param("i", $story_id);
                $check_stmt->execute();
                $check_stmt->store_result();
                
                if($check_stmt->num_rows > 0) {
                    $query = "UPDATE alumni_stories SET status = ?, status_updated_at = CURRENT_TIMESTAMP WHERE id = ?";
                    if($stmt = $conn->prepare($query)) {
                        $stmt->bind_param("si", $status, $story_id);
                        
                        if($stmt->execute()) {
                            echo json_encode([
                                'success' => true, 
                                'message' => "Story has been $status successfully"
                            ]);
                        } else {
                            throw new Exception("Update failed: " . $stmt->error);
                        }
                        $stmt->close();
                    } else {
                        throw new Exception("Prepare failed: " . $conn->error);
                    }
                } else {
                    throw new Exception("Story not found");
                }
                $check_stmt->close();
            } else {
                throw new Exception("Check prepare failed: " . $conn->error);
            }
        } else {
            throw new Exception("Invalid parameters");
        }
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
    exit;
}

// Fetch pending stories
$pending_query = "SELECT s.*, u.name as alumni_name 
                 FROM alumni_stories s 
                 JOIN users u ON s.user_id = u.id 
                 WHERE s.status = 'pending' 
                 ORDER BY s.created_at DESC";
$pending_stories = mysqli_query($conn, $pending_query);

// Fetch approved stories
$approved_query = "SELECT s.*, u.name as alumni_name 
                  FROM alumni_stories s 
                  JOIN users u ON s.user_id = u.id 
                  WHERE s.status = 'approved' 
                  ORDER BY s.created_at DESC";
$approved_stories = mysqli_query($conn, $approved_query);

// Fetch rejected stories
$rejected_query = "SELECT s.*, u.name as alumni_name 
                  FROM alumni_stories s 
                  JOIN users u ON s.user_id = u.id 
                  WHERE s.status = 'rejected' 
                  ORDER BY s.created_at DESC";
$rejected_stories = mysqli_query($conn, $rejected_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Alumni Stories - Admin Panel</title>
    <link rel="stylesheet" href="style2.css">
</head>
<body>
    <!-- Include your admin navigation here -->
    <div class="topnav" id="myTopnav">
    <div class="logo">
        <img src="../image/logo.png" alt="CHARUSAT Logo" style="background-color: white; height: 52px; vertical-align: middle;">
        <span style="vertical-align: middle; ">CE Connect</span>
    </div>
        <div class="topnav-right">
            <a href="index.php" >Home</a>
            <a href="alumni.php">Alumni</a>
            <a href="events.php">Events</a>
            <a href="jobs.php" >Job Post</a>
            <a href="stories.php" class="active">Stories</a>
            <a href="achievements.php" >Achievements</a>
            <!-- <a href="donation.php">Donation</a> -->
            <a href="gallery.php" >Gallery</a>
            <a href="help.php" >Help</a>
            <a href="profile.php" >Profile</a>
            <a  onclick="confirmLogout()">Logout</a>
            <div class="search-container">
                <input type="text" placeholder="Search...">
                <button type="submit">🔍</button>
            </div>
            <!-- <div class="profile-icon">
              
                <img src="Profile.jpg" alt="Profile" class="avatar" height="52px"> 
            </div> -->
    
        </div>
    </div>
    <div class="main-content">
        <div class="header">
            <h2>Manage Alumni Stories</h2>
        </div>

        <div class="stories-list">
            <h3>Pending Stories</h3>
            <table class="form-table">
                <thead>
                    <tr>
                        <th width="10%">Alumni Name</th>
                        <th width="13%">Title</th>
                        <th width="5%">Category</th>
                        <th width="42%">Story</th>
                        <th width="15%">Submitted Date</th>
                        <th width="15%">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($pending_stories)) { ?>
                        <tr>
                            <td style="white-space: nowrap;"><?php echo htmlspecialchars($row['alumni_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['title']); ?></td>
                            <td><span class="category-badge"><?php echo htmlspecialchars($row['category']); ?></span></td>
                            <td>
                                <div class="story-content">
                                    <?php 
                                    $story = htmlspecialchars($row['description']);
                                    echo (strlen($story) > 150) ? substr($story, 0, 150) . "..." : $story;
                                    ?>
                                </div>
                            </td>
                            <td style="white-space: nowrap;"><?php echo date('d M Y', strtotime($row['created_at'])); ?></td>
                            <td>
                                <div class="action-buttons">
                                    <button class="btn view-btn" onclick="handleStory(<?php echo $row['id']; ?>, 'approve')">Approve</button>
                                    <button class="btn delete-btn" onclick="handleStory(<?php echo $row['id']; ?>, 'reject')">Reject</button>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>

            <h3>Approved Stories</h3>
            <table class="form-table">
                <thead>
                    <tr>
                    <th width="10%">Alumni Name</th>
                        <th width="13%">Title</th>
                        <th width="5%">Category</th>
                        <th width="42%">Story</th>
                        <th width="15%">Submitted Date</th>
                        <th width="15%">Approved Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($approved_stories)) { ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($row['alumni_name']); ?></strong></td>
                            <td><?php echo htmlspecialchars($row['title']); ?></td>
                            <td><span class="category-badge"><?php echo htmlspecialchars($row['category']); ?></span></td>
                            <td>
                                <div class="story-content">
                                    <?php 
                                    $story = htmlspecialchars($row['description']);
                                    echo (strlen($story) > 150) ? substr($story, 0, 150) . "..." : $story;
                                    ?>
                                </div>
                            </td>
                            <td style="white-space: nowrap;"><?php echo date('d M Y', strtotime($row['created_at'])); ?></td>
                            <td><?php echo $row['status_updated_at'] ? date('d M Y', strtotime($row['status_updated_at'])) : 'N/A'; ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>

            <h3>Rejected Stories</h3>
            <table class="form-table">
                <thead>
                    <tr>
                    <th width="10%">Alumni Name</th>
                        <th width="13%">Title</th>
                        <th width="5%">Category</th>
                        <th width="42%">Story</th>
                        <th width="15%">Submitted Date</th>
                        <th width="15%">Rejected Date</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($rejected_stories)) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['alumni_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['title']); ?></td>
                            <td><?php echo htmlspecialchars($row['category']); ?></td>
                            <td>
                                <div class="story-content">
                                    <?php 
                                    $story = htmlspecialchars($row['description']);
                                    echo (strlen($story) > 150) ? substr($story, 0, 150) . "..." : $story;
                                    ?>
                                </div>
                            </td>
                            <td style="white-space: nowrap;"><?php echo date('d M Y', strtotime($row['created_at'])); ?></td>
                            <td><?php echo $row['status_updated_at'] ? date('d M Y', strtotime($row['status_updated_at'])) : 'N/A'; ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal for messages -->
    <div id="messageModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <p id="modalMessage"></p>
        </div>
    </div>

    <script>
    function handleStory(storyId, action) {
        if (!confirm(`Are you sure you want to ${action} this story?`)) {
            return;
        }

        const formData = new FormData();
        formData.append('story_id', storyId);
        formData.append('action', action);

        // Show loading state
        const button = event.target;
        const originalText = button.textContent;
        button.disabled = true;
        button.textContent = 'Processing...';

        fetch(window.location.href, {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                alert(data.message);
                window.location.reload();
            } else {
                throw new Error(data.error || 'Unknown error occurred');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert(error.message);
            // Reset button state
            button.disabled = false;
            button.textContent = originalText;
        });
    }

    // Add this function to show more details of the story
    function showFullStory(description) {
        alert(description);
    }
    function confirmLogout() {
            if (confirm("Are you sure you want to logout?")) {
                fetch('logout.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'action=logout'
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert("You have been successfully logged out.");
                        window.location.href = '../home.php'; 
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert("An error occurred during logout. Please try again.");
                });
            }
        }
    </script>

    <style>
        .form-table {
            table-layout: fixed; /* This is important for width control */
            width: 100%;
        }

        .form-table td {
            overflow: hidden;
            text-overflow: ellipsis;
            word-wrap: break-word;
        }

        .story-content {
            max-height: 80px;
            overflow-y: auto;
            line-height: 1.5;
            padding: 8px;
            background-color: #f9f9f9;
            border-radius: 4px;
            word-wrap: break-word;
        }

        .action-buttons {
            display: flex;
            gap: 5px;
            flex-direction: column;
        }

        .action-buttons .btn {
            padding: 4px 8px;
            font-size: 0.9em;
        }

        .category-badge {
            display: inline-block;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: 100%;
        }

        .btn:disabled {
            opacity: 0.7;
            cursor: not-allowed;
        }
    </style>
</body>
</html>
<?php include 'footer.php'; ?>