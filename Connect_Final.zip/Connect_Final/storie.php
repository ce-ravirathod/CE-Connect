<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CE Connect - Alumni Stories</title>
    <link href="styles/common.css" rel="stylesheet">
    <link href="styles/view_all.css" rel="stylesheet">
    <link href="styles/header_footer.css" rel="stylesheet">
    <script src="js/main.js"></script>
</head>
<body>
    <nav class="header-topnav">
        <div class="header-logo">
            <img src="https://d2lk14jtvqry1q.cloudfront.net/media/large_Charotar_University_of_Science_and_Technology_CHARUSAT_Anand_fdce544903_1202e15c5f.png" alt="CHARUSAT Logo">
            <span>CE Connect</span>
        </div>
        <div class="header-menu-icon" onclick="toggleMenu()">&#9776;</div>
        <div class="header-topnav-right">
            <a href="home.php">Home</a>
            <a href="aboutus.php" class="active">About Us</a>
            <a href="donation.php">Donation</a>
            <a href="Admin/login.php">Login</a>
        </div>
    </nav>

    <main class="view-all-container">
        <a href="home.php" class="back-button"></a>
        <h1 class="view-all-title">Alumni Stories</h1>
        
        <div class="view-all-grid">
            <?php
            // Include the database connection file
            include('connect.php');

            // Fetch stories from the database
            $sql = "SELECT id, title, description, date FROM stories"; // Adjust the query as needed
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo '<div class="view-all-item">';
                    echo '<div class="item-type">Story</div>';
                    echo '<h2 class="item-title">' . htmlspecialchars($row['title']) . '</h2>';
                    echo '<p class="item-description">' . htmlspecialchars($row['description']) . '</p>';
                    echo '<p class="item-date">' . htmlspecialchars($row['date']) . '</p>';
                    echo '<a href="#" class="item-read-more" onclick="showPopup(\'' . htmlspecialchars($row['title']) . '\', \'' . htmlspecialchars($row['description']) . '\', \'' . htmlspecialchars($row['date']) . '\', \'Lorem ipsum dolor sit amet, consectetur adipiscing elit.\')">Read More</a>';
                    echo '</div>';
                }
            } else {
                echo '<p>No stories found.</p>';
            }

            $conn->close();
            ?>
        </div>
    </main>

    <div id="popupOverlay" class="popup-overlay">
        <div class="popup-content">
            <span class="close-popup" onclick="closePopup()">&times;</span>
            <h2 id="popupTitle"></h2>
            <p id="popupSubtitle"></p>
            <p id="popupDate"></p>
            <p id="popupLorem"></p>
            <div id="popupContent"></div>
        </div>
    </div>
    <script>
        function showPopup(title, description, date, lorem) {
    document.getElementById('popupTitle').innerText = title;
    document.getElementById('popupSubtitle').innerText = description;
    document.getElementById('popupDate').innerText = date;
    document.getElementById('popupLorem').innerText = lorem;
    document.getElementById('popupOverlay').style.display = 'block';
}

function closePopup() {
    document.getElementById('popupOverlay').style.display = 'none';
}
    </script>
    
    <?php include('footer.php'); ?>
</body>
</html>
