<?php
// Include database connection
include 'connect.php'; // Ensure this path is correct

if (isset($_GET['id'])) {
    $uid = intval($_GET['id']); // Sanitize input
    $sql = "SELECT * FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $uid);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        echo json_encode([
            'title' => $user['name'],
            'description' => $user['description'], // Adjust based on your database structure
            'date' => $user['date_of_birth'] // Adjust based on your database structure
        ]);
    } else {
        echo json_encode(['error' => 'User not found.']);
    }
} else {
    echo json_encode(['error' => 'No ID provided.']);
}
?>