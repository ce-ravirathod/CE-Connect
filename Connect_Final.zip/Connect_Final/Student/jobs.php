<?php
session_start();
if (!isset($_SESSION['email'])) {
    // Redirect to a different page if not set
    header('Location: ../home.php');
    exit; // Ensure no further code is executed
}
include 'connect.php';

// Fetch job posts from the database
$sql = "SELECT * FROM job_posts ORDER BY date DESC";
$result = $conn->query($sql);

if (!$result) {
    die("Query failed: " . $conn->error);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Posts - Charusat Alumni System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="topnav" id="myTopnav">
    <div class="logo">
        <img src="image/logo.png" alt="CHARUSAT Logo" style="background-color: white; height: 52px; vertical-align: middle;">
        <span style="vertical-align: middle; ">CE Connect</span>
    </div>
        <div class="topnav-right">
            <a href="index.php">Home</a>
            <!-- <a href="alumni.php">Alumni</a> -->
            <a href="alumni.php">Alumni</a>
            <a href="events.php">Events</a>
            <a href="jobs.php" class="active">Job Post</a>
            <a href="stories.php" >Stories</a>
            <a href="syllabus.php">Syllabus</a>
            <a href="achievement.php">Achievements</a>
            <a href="gallery.php">Gallery</a>
            <a href="help.php">Help</a>
            <a href="profile.php" >Profile</a>
            <a href="#" onclick="confirmLogout()">Logout</a>
            <div class="search-container">
                <input type="text" placeholder="Search...">
                <button type="submit">🔍</button>
            </div>
          
        </div>
    </div>

    <div class="main-content">
       
        <div class="header">
            <h2>Existing Job Posts</h2>
        </div>

      

        <div class="jobs-list">
           
            <table class="jobs-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Date</th>
                        <th>Company Name</th>
                        <th>Job Type</th>
                        <th>Requirements</th>
                        <!-- <th>Actions</th> -->
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row["id"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["date"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["company_name"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["job_type"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["requirements"]) . "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4'>No job posts found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    

    <?php
    $conn->close();
    ?>

    <script>
       

    function confirmLogout() {
        if (confirm("Are you sure you want to logout?")) {
            fetch('logout.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=logout'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert("You have been successfully logged out.");
                    window.location.href = '../home.php'; 
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert("An error occurred during logout. Please try again.");
            });
        }
    }
    </script>
</body>
</html>

<?php include 'footer.php'; ?>