<?php
// Database connection
include 'connect.php';

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate input
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $phone = $conn->real_escape_string($_POST['phone']);
    $message = $conn->real_escape_string($_POST['message']);

    // Insert into database
    $sql = "INSERT INTO get_in_touch (name, email, phone, message) VALUES ('$name', '$email', '$phone', '$message')";
    
    if ($conn->query($sql) === TRUE) {
        $success_message = "Thank you for contacting us! We'll get back to you soon.";
    } else {
        $error_message = "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CE Connect - Contact Us</title>
    <link href="styles/common.css" rel="stylesheet">
    <link href="styles/aboutus.css" rel="stylesheet">
    <link href="styles/header_footer.css" rel="stylesheet">
    <style>
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: 4px;
        }
        .alert-success {
            color: #3c763d;
            background-color: #dff0d8;
            border-color: #d6e9c6;
        }
        .alert-error {
            color: #a94442;
            background-color: #f2dede;
            border-color: #ebccd1;
        }
    </style>
    <script src="js/main.js"></script>
</head>
<body>
    <nav class="header-topnav">
        <div class="header-logo">
            <img src="https://d2lk14jtvqry1q.cloudfront.net/media/large_Charotar_University_of_Science_and_Technology_CHARUSAT_Anand_fdce544903_1202e15c5f.png" alt="CHARUSAT Logo">
            <span>CE Connect</span>
        </div>
        
        <div class="header-menu-icon" onclick="toggleMenu()">&#9776;</div>
        <div class="header-topnav-right">
            <a href="home.php">Home</a>
            <a href="aboutus.php" class="active">About Us</a>
            <a href="donation.php">Donation</a>
            <a href="login.php">Login</a>
        </div>
    </nav>

    <main class="contact-us-container">
        <section class="hero-section">
            <h1>CONTACT US</h1>
            <p>We're here to help. Reach out to us for any questions or support you need.</p>
        </section>

        <section class="association">
            <h2>Alumni Association</h2>
            <div class="board-members">
                <div class="board-member">
                    <img src="images/board-member-1.jpeg" alt="Board Member 1">
                    <h3>John Doe</h3>
                    <p>President</p>
                </div>
                <div class="board-member">
                    <img src="images/board-member-2.jpeg" alt="Board Member 2">
                    <h3>Jane Smith</h3>
                    <p>Vice President</p>
                </div>
            </div>
            <div class="info-boxes">
                <div class="info-box">
                    <h3>How to help?</h3>
                    <p>Support our alumni community through mentorship, donations, or volunteering. Your contribution makes a difference.</p>
                    <a href="#" class="learn-more-btn">Learn More</a>
                    <!-- in this page pop content -->
                </div>
                <div class="info-box">
                    <h3>Our mission</h3>
                    <p>We strive to foster lifelong connections among alumni, support their professional growth, and strengthen the CE community.</p>
                    <a href="#" class="learn-more-btn">Learn More</a>
                </div>
                <div class="info-box">
                    <h3>Contact Us</h3>
                    <p><strong>Location:</strong> Charusat University, Changa, Petlad, Anand, Gujarat - 388421</p>
                    <p><strong>Office Hours:</strong> Monday-Friday, 9:00 AM - 6:00 PM</p>
                    <p><strong>Email:</strong> contact@ceconnect.edu</p>
                    <p><strong>Phone:</strong>+1 (234) 567-8910</p>
                </div>
            </div>
        </section>

        <section class="contact-form">
            <h2>Get in Touch</h2>
            <?php if (isset($success_message)): ?>
                <div class="alert alert-success">
                    <?php echo $success_message; ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($error_message)): ?>
                <div class="alert alert-error">
                    <?php echo $error_message; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <input type="text" name="name" placeholder="Name" required>
                <input type="email" name="email" placeholder="Email" required>
                <input type="tel" name="phone" placeholder="Phone" required>
                <textarea name="message" placeholder="Message" required></textarea>
                <button type="submit">Send Message</button>
            </form>
        </section>
    </main>
    
    <?php include('footer.php'); ?>
</body>
</html>
