<?php
session_start();
include 'connect.php';

if (!isset($_SESSION['user_id'])) {
    die("User ID is not set in the session.");
}
$user_id = $_SESSION['user_id'];

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission for adding or updating achievements
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action']) && $_POST['action'] == 'add') {
        // Add new achievement
        $title = $_POST['title'];
        $description = $_POST['description'];
        $date = $_POST['date'];
        $category = $_POST['category'];

        // Ensure user_id is valid
        if (!is_numeric($user_id)) {
            die("Invalid user ID.");
        }

        $query = "INSERT INTO achievements (user_id, item_title, item_subtitle, date, category) VALUES ('$user_id', '$title', '$description', '$date', '$category')";
        if ($conn->query($query) === TRUE) {
            header('Location: achievements.php');
        } else {
            echo "Error adding record: " . $conn->error;
        }
    } elseif (isset($_POST['action']) && $_POST['action'] == 'update') {
        // Update existing achievement
        $id = $_POST['id'];
        $title = $_POST['title'];
        $description = $_POST['description'];
        $date = $_POST['date'];
        $category = $_POST['category'];

        $query = "UPDATE achievements SET item_title='$title', item_subtitle='$description', date='$date', category='$category' WHERE id=$id";
        if ($conn->query($query) === TRUE) {
            header('Location: achievements.php');
        } else {
            echo "Error updating record: " . $conn->error;
        }
    }
}

// Handle deletion of achievements
if (isset($_GET['action']) && $_GET['action'] == 'delete') {
    $id = $_GET['id'];
    $query = "DELETE FROM achievements WHERE id=$id";
    if ($conn->query($query) === TRUE) {
        header('Location: achievements.php');
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}

// Fetch all achievements for display
$query = "SELECT * FROM achievements ORDER BY date DESC";
$result = $conn->query($query);

$_SESSION['user_id'] = $user_id; // Set this when the user logs in

// Fetch achievement for editing if action is edit
$achievement = null;
if (isset($_GET['action']) && $_GET['action'] == 'edit') {
    $id = $_GET['id'];
    $query = "SELECT * FROM achievements WHERE id = $id AND user_id = $user_id";
    $resultEdit = $conn->query($query);
    if ($resultEdit->num_rows > 0) {
        $achievement = $resultEdit->fetch_assoc();
    } else {
        echo "Achievement not found or you do not have permission to edit this achievement.";
    }
}

// Debugging: Check if the edit action is being triggered
if (isset($_GET['action']) && $_GET['action'] == 'edit') {
    echo "Edit action triggered for ID: " . htmlspecialchars($_GET['id']);
}

// Debugging: Check the achievement fetched for editing
if ($achievement) {
    echo "Editing achievement: " . htmlspecialchars($achievement['item_title']);
} else {
    echo "No achievement found for editing.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Manage Achievements</title>
    <link  href="style.css" rel="stylesheet" >
    <link href="../styles/common.css" rel="stylesheet">
    <link href="../styles/home.css" rel="stylesheet">
    <link href="../styles/view_all.css" rel="stylesheet">
    <link href="../styles/header_footer.css" rel="stylesheet">
    <script src="../js/main.js"></script>
    <style>
        footer {
            display: flex; /* Use flexbox for alignment */
            justify-content: center; /* Center content horizontally */
            align-items: center; /* Center content vertically */
            text-align: center; /* Center the text */
            padding: 20px; /* Add some padding */
            background-color: #f1f1f1; /* Optional: background color */
            width: 100%; /* Ensure footer takes full width */
            position: relative; /* Ensure proper positioning */
            bottom: 0; /* Stick to the bottom if needed */
        }
    </style>
</head>
<body>
<div class="topnav" id="myTopnav">
    <div class="logo">
        <img src="../image/logo.png" alt="CHARUSAT Logo" style="background-color: white; height: 52px; vertical-align: middle;">
        <span style="vertical-align: middle; ">CE Connect</span>
    </div>
        <div class="topnav-right">
            <a href="index.php" >Home</a>
            <a href="alumni.php">Alumni</a>
            <a href="events.php">Events</a>
            <a href="jobs.php" >Job Post</a>
            <a href="stories.php" >Stories</a>
            <a href="achievements.php" class="active">Achievements</a>
            <!-- <a href="donation.php">Donation</a> -->
            <a href="gallery.php" >Gallery</a>
            <a href="help.php" >Help</a>
            <a href="profile.php" >Profile</a>
            <a  onclick="confirmLogout()">Logout</a>
            <div class="search-container">
                <input type="text" placeholder="Search...">
                <button type="submit">🔍</button>
            </div>
            <!-- <div class="profile-icon">
              
                <img src="Profile.jpg" alt="Profile" class="avatar" height="52px"> 
            </div> -->
    
        </div>
    </div>

<main>
<div class="main-content">
    <div class="header">
    <h2 >Manage Achievements</h2>
    </div>
    <div class="add-job">
    <form action="achievements.php" method="POST">
        <h3>Add New Achievement</h3>
        <input type="hidden" name="action" value="add">
        <table class="form-table" >
            <tr>
                <td >
                    <label for="date">Date of Achievement:</label> 
                    <input type="date" id="date" name="date" required value="<?php echo date('Y-m-d'); ?>"> 
                </td>
                <td >
                    <label for="title">Title:</label> 
                    <input type="text" id="title" name="title" required> 
                </td>
                
                
                </tr>
                <tr>
                    <td >
                        <label for="description">Description:</label> 
                        <textarea id="description" name="description" required> </textarea>
                    </td>
                    <td> <label for="category">Category:</label> 
                    <select id="category" name="category" required>
                        <option value="Academic">Academic</option>
                        <option value="Sports">Sports</option>
                        <option value="Research">Research</option>
                        <option value="Professional">Professional</option>
                        <option value="Entrepreneurship">Entrepreneurship</option>
                        <option value="Social Work">Social Work</option>
                        <option value="Other">Other</option>
                    </select>
                </td>
        <td > <button type="submit" style="    background-color: #4CAF50;
    color: white;
    border: none;
    padding: 12px 20px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
    transition: background-color 0.3s;
    float: right;
    margin-top: 10px;">Add Achievement</button> </td>
       
            </tr>
            <tr>
        </tr>
        </table>
    </form>
</div>

    <div class="jobs-list add-job">
        <h3>Existing Achievements</h3>
        <table class="jobs-table">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Date</th>
                    <th>Category</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($achievement = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>{$achievement['item_title']}</td>";
                        echo "<td>{$achievement['item_subtitle']}</td>";
                        echo "<td>{$achievement['date']}</td>";
                        echo "<td>{$achievement['category']}</td>";
                        echo "<td>";
                        echo "<button class='view-btn' onclick=\"openModal('{$achievement['id']}', '{$achievement['item_title']}', '{$achievement['item_subtitle']}', '{$achievement['date']}', '{$achievement['category']}')\">Edit</button>  ";
                        echo "<button class='delete-btn' onclick=\"window.location.href='achievements.php?action=delete&id={$achievement['id']}'\">Delete</button>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No achievements found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <?php if ($achievement): ?>
        <div class="add-job">
            <h3>Edit Achievement</h3>
            <form action="achievements.php" method="POST">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="id" value="<?php echo $achievement['id']; ?>">
                
                <label for="title">Title:</label>
                <input type="text" id="title" name="title" value="<?php echo $achievement['item_title']; ?>" required>
                
                <label for="description">Description:</label>
                <textarea id="description" name="description" required><?php echo $achievement['item_subtitle']; ?></textarea>
                
                <label for="date">Date of Achievement:</label>
                <input type="date" id="date" name="date" value="<?php echo $achievement['date']; ?>" required>
                
                <label for="category">Category:</label>
                <select id="category" name="category" required>
                    <option value="Academic" <?php if ($achievement['category'] == 'Academic') echo 'selected'; ?>>Academic</option>
                    <option value="Sports" <?php if ($achievement['category'] == 'Sports') echo 'selected'; ?>>Sports</option>
                    <option value="Research" <?php if ($achievement['category'] == 'Research') echo 'selected'; ?>>Research</option>
                    <option value="Professional" <?php if ($achievement['category'] == 'Professional') echo 'selected'; ?>>Professional</option>
                    <option value="Entrepreneurship" <?php if ($achievement['category'] == 'Entrepreneurship') echo 'selected'; ?>>Entrepreneurship</option>
                    <option value="Social Work" <?php if ($achievement['category'] == 'Social Work') echo 'selected'; ?>>Social Work</option>
                    <option value="Other" <?php if ($achievement['category'] == 'Other') echo 'selected'; ?>>Other</option>
                </select>
                
                <button type="submit" style="    background-color: #4CAF50;
    color: white;
    border: none;
    padding: 12px 20px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
    transition: background-color 0.3s;
    float: right;
    margin-top: 10px;">Update Achievement</button>
            </form>
        </div>
    <?php endif; ?>
    </div>
</main>

<!-- Modal Structure -->
<div id="achievementModal" class="modal">
    <div class="modal-content">
        <span class="close" id="closeModal">&times;</span>
        <h3>Edit Achievement</h3>
        <form id="editAchievementForm" action="achievements.php" method="POST">
            <input type="hidden" name="action" value="update">
            <input type="hidden" name="id" id="modalAchievementId">
            
            <label for="modalTitle">Title:</label>
            <input type="text" id="modalTitle" name="title" required>
            
            <label for="modalDescription">Description:</label>
            <textarea id="modalDescription" name="description" required></textarea>
            
            <label for="modalDate">Date of Achievement:</label>
            <input type="date" id="modalDate" name="date" required>
            
            <label for="modalCategory">Category:</label>
            <select id="modalCategory" name="category" required>
                <option value="Academic">Academic</option>
                <option value="Sports">Sports</option>
                <option value="Research">Research</option>
                <option value="Professional">Professional</option>
                <option value="Entrepreneurship">Entrepreneurship</option>
                <option value="Social Work">Social Work</option>
                <option value="Other">Other</option>
            </select>
            
            <div style="text-align: right; margin-top: 20px;">
                <button type="submit" style="background-color: #4CAF50; color: white; border: none; padding: 12px 20px; border-radius: 4px; cursor: pointer; font-size: 16px; transition: background-color 0.3s;">Update Achievement</button>
            </div>
        </form>
    </div>
</div>

</body>
</html>

<?php include 'footer.php'; ?>

<script>
// JavaScript to handle modal display
document.addEventListener('DOMContentLoaded', function() {
    const modal = document.getElementById("achievementModal");
    const closeModal = document.getElementById("closeModal");

    // Function to open the modal
    window.openModal = function(id, title, description, date, category) {
        document.getElementById("modalAchievementId").value = id;
        document.getElementById("modalTitle").value = title;
        document.getElementById("modalDescription").value = description;
        document.getElementById("modalDate").value = date;
        document.getElementById("modalCategory").value = category;
        modal.style.display = "block";
    }

    // When the user clicks on <span> (x), close the modal
    closeModal.onclick = function() {
        modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
});
</script>
<script>
    function confirmLogout() {
        if (confirm("Are you sure you want to logout?")) {
            fetch('logout.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=logout'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert("You have been successfully logged out.");
                    window.location.href = '../home.php'; 
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert("An error occurred during logout. Please try again.");
            });
        }
    }
    </script>