<?php
// Include database connection
include 'alumni.php';
include 'connect.php'; // Ensure this path is correct

if (isset($_POST['id'])) {
    $uid = intval($_POST['id']); // Sanitize input
    $sql = "DELETE FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $uid);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to delete user.']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'No ID provided.']);
}
?>