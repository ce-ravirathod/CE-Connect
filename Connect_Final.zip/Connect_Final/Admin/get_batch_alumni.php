<?php
session_start();
if (!isset($_SESSION['email'])) {
    header('Location: ../home.php');
    exit;
}

include 'connect.php';

// Get the parameters from the request
$year = isset($_GET['year']) ? $_GET['year'] : '';
$dob = isset($_GET['dob']) ? $_GET['dob'] : '';
$id = isset($_GET['id']) ? $_GET['id'] : '';
$email = isset($_GET['email']) ? $_GET['email'] : '';
$name = isset($_GET['name']) ? $_GET['name'] : '';
$gender = isset($_GET['gender']) ? $_GET['gender'] : '';
$college_id = isset($_GET['college_id']) ? $_GET['college_id'] : '';
$contact = isset($_GET['contact']) ? $_GET['contact'] : '';
$work_status = isset($_GET['work_status']) ? $_GET['work_status'] : '';
$user_type = isset($_GET['user_type']) ? $_GET['user_type'] : '';

// Build the SQL query with filters
$sql = "SELECT id, email, name, date_of_birth, gender, college_id, contact, passing_year, work_status, user_type 
        FROM users 
        WHERE user_type = 'alumni'";

$conditions = [];
$params = [];

// Add conditions based on the filters provided
if ($year) {
    $conditions[] = "passing_year = ?";
    $params[] = $year;
}
if ($dob) {
    $conditions[] = "date_of_birth = ?";
    $params[] = $dob;
}
if ($id) {
    $conditions[] = "id = ?";
    $params[] = $id;
}
if ($email) {
    $conditions[] = "email LIKE ?";
    $params[] = '%' . $email . '%'; // Use LIKE for partial matches
}
if ($name) {
    $conditions[] = "name LIKE ?";
    $params[] = '%' . $name . '%'; // Use LIKE for partial matches
}
if ($gender) {
    $conditions[] = "gender = ?";
    $params[] = $gender;
}
if ($college_id) {
    $conditions[] = "college_id = ?";
    $params[] = $college_id;
}
if ($contact) {
    $conditions[] = "contact LIKE ?";
    $params[] = '%' . $contact . '%'; // Use LIKE for partial matches
}
if ($work_status) {
    $conditions[] = "work_status = ?";
    $params[] = $work_status;
}
if ($user_type) {
    $conditions[] = "user_type = ?";
    $params[] = $user_type;
}

// Append conditions to the SQL query if any
if (count($conditions) > 0) {
    $sql .= " AND " . implode(' AND ', $conditions);
}

// Debugging: Output the final SQL query and parameters
error_log("SQL Query: " . $sql);
error_log("Parameters: " . json_encode($params));

$stmt = $conn->prepare($sql);

// Bind parameters dynamically
if ($params) {
    $stmt->bind_param(str_repeat('s', count($params)), ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

$alumni = array();
while ($row = $result->fetch_assoc()) {
    $alumni[] = array(
        'id' => $row['id'],
        'email' => $row['email'],
        'name' => $row['name'],
        'dob' => $row['date_of_birth'],
        'gender' => $row['gender'],
        'college_id' => $row['college_id'],
        'contact' => $row['contact'],
        'passing_year' => $row['passing_year'],
        'work_status' => $row['work_status'],
        'user_type' => $row['user_type']
    );
}

// Return the results as JSON
header('Content-Type: application/json');
echo json_encode($alumni);
?>
