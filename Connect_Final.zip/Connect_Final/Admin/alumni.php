<?php
session_start();
$user_id = isset($_POST['user_id']) ? $_POST['user_id'] : 'Guest';
$is_admin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'] === true;

// Include the database connection
include 'connect.php'; // Ensure this path is correct

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $uid = intval($_POST['delete_id']); // Sanitize input
    // $sql = "DELETE FROM users WHERE id = ?;
    $sql = "DELETE FROM users WHERE id = ? AND user_type IN ('alumni', 'student')";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $uid);
    
    if ($stmt->execute()) {
        echo json_encode(array('success' => true)); // Use array() instead of []
        exit; // Exit after handling the delete
    } else {
        echo json_encode(array('success' => false, 'error' => 'Failed to delete user.')); // Use array() instead of []
        exit; // Exit after handling the error
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alumni Records - Charusat Alumni System</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* Add some basic styling for the filter inputs */
        th input[type="text"],
        th input[type="date"],
        th select {
            width: 100%; /* Full width */
            padding: 5px; /* Padding for better appearance */
            box-sizing: border-box; /* Include padding in width */
        }
        th {
            text-align: left; /* Align text to the left */
        }
        .filter-container {
            margin-bottom: 10px; /* Space below the filter row */
        }
    </style>
</head>
<body>
    <div class="topnav" id="myTopnav">
    <div class="logo">
        <img src="../image/logo.png" alt="CHARUSAT Logo" style="background-color: white; height: 52px; vertical-align: middle;">
        <span style="vertical-align: middle; ">CE Connect</span>
    </div>
    <div class="topnav-right">
            <a href="index.php">Home</a>
            <a href="alumni.php"  class="active">Alumni</a>
            <a href="events.php">Events</a>
            <a href="jobs.php" >Job Post</a>
            <a href="stories.php" >Stories</a>
            <a href="achievements.php" >Achievements</a>
            <!-- <a href="donation.php">Donation</a> -->
            <a href="gallery.php" >Gallery</a>
            <a href="help.php" >Help</a>
            <a href="profile.php" >Profile</a>
            <a  onclick="confirmLogout()">Logout</a>
            <div class="search-container">
                <input type="text" placeholder="Search...">
                <button type="submit">🔍</button>
            </div>
            <!-- <div class="profile-icon">
              
                <img src="Profile.jpg" alt="Profile" class="avatar" height="52px"> 
            </div> -->
    
        </div>
    </div>

    <div class="main-content">
        <div class="header">
            <h2>Alumni Records</h2>
        </div>

         <div class="alumni-list">
            <table >
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Email</th>
                        <th>Name</th>
                        <th>Date of Birth</th>
                        <th>Gender</th>
                        <th>College ID</th>
                        <th>Contact</th>
                        <th>Passing Year</th>
                        <th>Work Status</th>
                        <th>User Type</th>
                        <th>Action</th>
                    </tr>
                    <tr class="filter-container">
                        <th><input type="text" placeholder="Filter ID" onkeyup="filterTable()" style="width: 60%;"></th>
                        <th><input type="text" placeholder="Filter Email" onkeyup="filterTable()"></th>
                        <th><input type="text" placeholder="Filter Name" onkeyup="filterTable()"></th>
                        <th><input type="date" placeholder="Filter DOB" onkeyup="filterTable()"></th>
                        <th>
                            <select id="genderFilter" onchange="filterTable()">
                                <option value="">All</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                        </th>
                        <th><input type="text" placeholder="Filter College ID" onkeyup="filterTable()"></th>
                        <th><input type="text" placeholder="Filter Contact" onkeyup="filterTable()"></th>
                        <th>
                            <select id="passingYearFilter" onchange="filterTable()">
                                <option value="">All</option>
                                <?php
                                for ($year = 2024; $year >= 2004; $year--) {
                                    echo "<option value='$year'>$year</option>";
                                }
                                ?>
                            </select>
                        </th>
                        <th>
                            <select id="workStatusFilter" onchange="filterTable()">
                                <option value="">All</option>
                                <option value="Unemployed">Unemployed</option>
                                <option value="Employed">Employed</option>
                                <option value="Student">Student</option>
                                <option value="Retired">Retired</option>
                            </select>
                        </th>
                        <th>
                            <select id="userTypeFilter" onchange="filterTable()">
                                <option value="">All</option>
                                <option value="alumni">Alumni</option>
                                <option value="student">Student</option>
                            </select>
                        </th>
                    </tr>
                </thead>
                <tbody id="alumniTableBody">
                    <?php
                    try {
                        // Fetch data from users table for alumni and students only
                        $sql = "SELECT * FROM users WHERE user_type IN ('alumni', 'student')";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            while ($user = $result->fetch_assoc()) {
                                echo "<tr>
                                        <td>{$user['id']}</td>
                                        <td>{$user['email']}</td>
                                        <td>{$user['name']}</td>
                                        <td>{$user['date_of_birth']}</td>
                                        <td>{$user['gender']}</td>
                                        <td>{$user['college_id']}</td>
                                        <td>{$user['contact']}</td>
                                        <td>{$user['passing_year']}</td>
                                        <td>{$user['work_status']}</td>
                                        <td>{$user['user_type']}</td>
                                        <td>
                                            <button class='delete-btn' data-uid='{$user['id']}'>Delete</button>
                                        </td>
                                      </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='11'>No users found.</td></tr>";
                        }
                    } catch (Exception $e) {
                        echo "Error: " . $e->getMessage();
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        document.querySelectorAll('.delete-btn').forEach(button => {
            button.addEventListener('click', function() {
                var uid = this.getAttribute('data-uid');
                if (confirm('Are you sure you want to delete this user Id '+ uid )) {
                    fetch('', { // Send to the same file
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: `delete_id=${uid}`
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert('User deleted successfully');
                            this.closest('tr').remove(); // Remove the row from the table
                        } else {
                            alert('Error: ' + data.error);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('An error occurred while deleting the user.');
                    });
                }
            });
        });

        function confirmLogout() {
            if (confirm("Are you sure you want to logout?")) {
                fetch('logout.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'action=logout'
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert("You have been successfully logged out.");
                        window.location.href = '../home.php'; 
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert("An error occurred during logout. Please try again.");
                });
            }
        }

function filterTable() {
    console.log("filterTable called"); // Debugging log
    const idInput = document.querySelector('input[placeholder="Filter ID"]').value.toLowerCase();
    const emailInput = document.querySelector('input[placeholder="Filter Email"]').value.toLowerCase();
    const nameInput = document.querySelector('input[placeholder="Filter Name"]').value.toLowerCase(); // Name filter
    const dobInput = document.querySelector('input[placeholder="Filter DOB"]').value; // DOB filter
    const genderInput = document.querySelector('#genderFilter').value.toLowerCase(); // Gender filter
    const collegeIdInput = document.querySelector('input[placeholder="Filter College ID"]').value.toLowerCase(); // College ID filter
    const contactInput = document.querySelector('input[placeholder="Filter Contact"]').value.toLowerCase(); // Contact filter
    const passingYearInput = document.querySelector('#passingYearFilter').value; // Passing Year filter
    const workStatusInput = document.querySelector('#workStatusFilter').value.toLowerCase(); // Work Status filter
    const userTypeInput = document.querySelector('#userTypeFilter').value.toLowerCase(); // User Type filter
    const rows = document.querySelectorAll('#alumniTableBody tr');

    rows.forEach(row => {
        const id = row.cells[0].textContent.toLowerCase();
        const email = row.cells[1].textContent.toLowerCase();
        const name = row.cells[2].textContent.toLowerCase(); // Fixed name filtering
        const dob = row.cells[3].textContent;
        const gender = row.cells[4].textContent.toLowerCase();
        const collegeId = row.cells[5].textContent.toLowerCase();
        const contact = row.cells[6].textContent.toLowerCase();
        const passingYear = row.cells[7].textContent;
        const workStatus = row.cells[8].textContent.toLowerCase();
        const userType = row.cells[9].textContent.toLowerCase();

        const matches = 
            (idInput === "" || id.includes(idInput)) &&
            (emailInput === "" || email.includes(emailInput)) &&
            (nameInput === "" || name.includes(nameInput)) && // Fixed comparison
            (dobInput === "" || dob === dobInput) &&
            (genderInput === "" || gender === genderInput) &&
            (collegeIdInput === "" || collegeId.includes(collegeIdInput)) &&
            (contactInput === "" || contact.includes(contactInput)) &&
            (passingYearInput === "" || passingYear === passingYearInput) &&
            (workStatusInput === "" || workStatus === workStatusInput) &&
            (userTypeInput === "" || userType === userTypeInput);

        row.style.display = matches ? "" : "none";
    });
}


        // Ensure filterTable is called on the correct events
        document.querySelectorAll('input[type="text"], input[type="date"], select').forEach(input => {
            input.addEventListener('keyup', filterTable); // For text and date inputs
            input.addEventListener('change', filterTable); // For select inputs
        });
    </script>

</body>
</html>

<?php include 'footer.php'; ?>