<?php
session_start();
if (!isset($_SESSION['email'])) {
    // Redirect to a different page if not set
    header('Location: ../home.php');
    exit; // Ensure no further code is executed
}
include 'connect.php';

// Check if the form is submitted for adding a job post
if ($_SERVER["REQUEST_METHOD"] == "POST" && !isset($_POST['delete_id'])) {
    // Sanitize and validate input data
    $date = $conn->real_escape_string($_POST['date']);
    $company_name = $conn->real_escape_string($_POST['company_name']);
    $job_type = $conn->real_escape_string($_POST['type']);
    $requirements = $conn->real_escape_string($_POST['requirements']);

    // Prepare SQL statement
    $sql = "INSERT INTO job_posts (date, company_name, job_type, requirements) VALUES (?, ?, ?, ?)";
    
    // Create a prepared statement
    $stmt = $conn->prepare($sql);
    
    // Bind parameters to the prepared statement
    $stmt->bind_param("ssss", $date, $company_name, $job_type, $requirements);
    
    // Execute the statement
    if ($stmt->execute()) {
        $message = "Job post added successfully!";
        // Redirect to the same page to prevent resubmission
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    } else {
        $message = "Error: " . $stmt->error;
    }
    
    // Close the statement
    $stmt->close();
}


// Fetch job posts from the database
$sql = "SELECT * FROM job_posts ORDER BY date DESC";
$result = $conn->query($sql);

if (!$result) {
    die("Query failed: " . $conn->error);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Posts - Charusat Alumni System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="topnav" id="myTopnav">
    <div class="logo">
        <img src="image/logo.png" alt="CHARUSAT Logo" style="background-color: white; height: 52px; vertical-align: middle;">
        <span style="vertical-align: middle; ">CE Connect</span>
    </div>
        <div class="topnav-right">
            <a href="index.php">Home</a>
            <a href="alumni.php">Alumni</a>
            <a href="events.php">Events</a>
            <a href="jobs.php" class="active">Job Post</a>
            <a href="Stories.php">Stories</a>
            <!-- <a href="donation.php">Donation</a> -->
            <a href="achievement.php">Achievements</a>
            <a href="gallery.php">Gallery</a>
            <a href="help.php">Help</a>
            <a href="profile.php" >Profile</a>
            <a href="#" onclick="confirmLogout()">Logout</a>
            <div class="search-container">
                <input type="text" placeholder="Search...">
                <button type="submit">🔍</button>
            </div>
          
        </div>
    </div>

    <div class="main-content">
       
        <div class="header">
            <h2>Add New Job Post</h2>
        </div>

        <div class="add-job">
            
            <form id="job-form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                <table class="form-table" >
                    <tr>
                        <td>
                            <label for="date">Job post date:</label>
                            <input type="date" id="date" name="date" required value="<?php echo date('Y-m-d'); ?>">
                        </td>
                        <td>
                            <label for="company_name">Company Name:</label>
                            <input type="text" id="company_name" name="company_name" required placeholder="Enter Company Name" >
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="requirements">Requirements:</label>
                            <textarea id="requirements" name="requirements" rows="4" required placeholder="Enter Requirement Details"></textarea>
                        </td>
                        <td>
                            <label for="type">Job Type:</label>
                            <select id="type" name="type" required>
                                <option value="Full Time">Full Time</option>
                                <option value="Part Time">Part Time</option>
                                <option value="Internship">Internship</option>
                            </select>
                            <button type="submit" id="insert-btn">Add Job Post</button>
                        </td>
                    </tr>
                   
                </table>
            </form>
        </div>

        <div class="jobs-list">
            <h3>Existing Job Posts</h3>
            <table class="jobs-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Date</th>
                        <th>Company Name</th>
                        <th>Job Type</th>
                        <th>Requirements</th>
                        <!-- <th>Actions</th> -->
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row["id"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["date"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["company_name"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["job_type"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["requirements"]) . "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4'>No job posts found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    

    <?php
    $conn->close();
    ?>

    <script>
        // Handle insert button click
        document.getElementById('insert-btn').addEventListener('click', function(event) {
            const form = document.getElementById('job-form');
            if (!form.checkValidity()) {
                event.preventDefault(); // Prevent form submission if invalid
                alert("Please fill in all required fields.");
            }
        });

    function confirmLogout() {
        if (confirm("Are you sure you want to logout?")) {
            fetch('logout.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=logout'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert("You have been successfully logged out.");
                    window.location.href = '../home.php'; 
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert("An error occurred during logout. Please try again.");
            });
        }
    }
    </script>
</body>
</html>

<?php include 'footer.php'; ?>